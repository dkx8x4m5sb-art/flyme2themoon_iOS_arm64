//
//  fm_lua.h
//  Lua 5.1 的部分 API 在 C 里是宏（lua_tostring / lua_setglobal / lua_newtable /
//  lua_pushcfunction / lua_istable），Swift 看不到宏，所以在这里包成真函数。
//

#ifndef FM_LUA_H
#define FM_LUA_H

#include "lua.h"

/// 新建 Lua 状态并注册 base / table / string / math / coroutine / debug。失败返回 NULL。
lua_State *fm_lua_new(void);

/// lua_tolstring(L, idx, NULL)
const char *fm_lua_tostring(lua_State *L, int idx);
/// lua_setfield(L, LUA_GLOBALSINDEX, name)
void fm_lua_setglobal(lua_State *L, const char *name);
/// lua_createtable(L, 0, 0)
void fm_lua_newtable(lua_State *L);
/// lua_pushcclosure(L, fn, 0)
void fm_lua_pushcfunction(lua_State *L, lua_CFunction fn);
/// lua_type(L, idx) == LUA_TTABLE
int fm_lua_istable(lua_State *L, int idx);
/// lua_settop(L, -(n) - 1)
void fm_lua_pop(lua_State *L, int n);

#endif
