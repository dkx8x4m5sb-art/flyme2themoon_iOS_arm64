//
//  fm_lua.c
//  建状态 + 只开需要的库；另外给 Swift 补上几个宏包装。
//

#include "fm_lua.h"
#include "lauxlib.h"
#include "lualib.h"

// liolib.c / loslib.c / loadlib.c 没有编进来，但 luaL_openlibs 会引用这些符号，补空实现。
int luaopen_io(lua_State *L) { (void)L; return 0; }
int luaopen_os(lua_State *L) { (void)L; return 0; }
int luaopen_loadlib(lua_State *L) { (void)L; return 0; }
int luaopen_package(lua_State *L) { (void)L; return 0; }

// Lua 5.1 的 coroutine 库是 base 的一部分（lbaselib.c），没有 luaopen_coroutine。
static const luaL_Reg fm_libs[] = {
    {"", luaopen_base},
    {LUA_TABLIBNAME, luaopen_table},
    {LUA_STRLIBNAME, luaopen_string},
    {LUA_MATHLIBNAME, luaopen_math},
    {LUA_DBLIBNAME, luaopen_debug},
    {NULL, NULL},
};

lua_State *fm_lua_new(void) {
    lua_State *L = luaL_newstate();
    if (L == NULL) {
        return NULL;
    }
    for (const luaL_Reg *lib = fm_libs; lib->func != NULL; lib++) {
        lua_pushcfunction(L, lib->func);
        lua_pushstring(L, lib->name);
        lua_call(L, 1, 0);
    }
    return L;
}

const char *fm_lua_tostring(lua_State *L, int idx) {
    return lua_tolstring(L, idx, NULL);
}

void fm_lua_setglobal(lua_State *L, const char *name) {
    lua_setfield(L, LUA_GLOBALSINDEX, name);
}

void fm_lua_newtable(lua_State *L) {
    lua_createtable(L, 0, 0);
}

void fm_lua_pushcfunction(lua_State *L, lua_CFunction fn) {
    lua_pushcclosure(L, fn, 0);
}

int fm_lua_istable(lua_State *L, int idx) {
    return lua_type(L, idx) == LUA_TTABLE;
}

void fm_lua_pop(lua_State *L, int n) {
    lua_settop(L, -(n) - 1);
}
