#!/usr/bin/env bash
# ci/pipeline.sh — 全部构建逻辑；workflow 只负责 checkout + 跑这个脚本 + 传 artifact。
# 素材来源（按优先级）：仓库里的 assets-lite.zip（解压出来的 Resources/atlas/normalized.json 即视为就位）→ Release 里的两个 ipa。
# 任何一步失败都会把原始输出推到 ci-logs 分支的 build-log.md（含失败命令与行号）。
set -euo pipefail
cd "$(dirname "$0")/.."

RAW=ci-raw.log
LOG=build-log.md
: > "$RAW"
exec > >(tee -a "$RAW") 2>&1

PUSHED=0
push_log() {
  local outcome="$1"
  [ "$PUSHED" = 1 ] && return 0
  PUSHED=1
  {
    echo "# outcome: $outcome"
    echo "# commit: ${GITHUB_SHA:-local}"
    echo "# time: $(date -u +%FT%TZ)"
    echo
    echo "----- 关键错误 -----"
    grep -E "error:|Error:|fatal:|No such file|not found|BUILD (SUCCEEDED|FAILED)" "$RAW" 2>/dev/null | tail -200 || true
    echo
    echo "----- 原始尾部 -----"
    tail -150 "$RAW" 2>/dev/null || true
  } > "$LOG"
  if git rev-parse --git-dir >/dev/null 2>&1; then
    git config user.name "dsh-ci" || true
    git config user.email "dsh-ci@users.noreply.github.com" || true
    git checkout --orphan ci-logs 2>/dev/null || git checkout ci-logs 2>/dev/null || true
    git rm -rf --cached . >/dev/null 2>&1 || true
    git add -f "$LOG" || true
    git commit -m "ci: ${GITHUB_SHA:-local}" >/dev/null 2>&1 || true
    git push origin ci-logs --force >/dev/null 2>&1 || echo "!! 推 ci-logs 失败（看 token 权限）"
  fi
}

on_err() {
  local code=$?
  echo "::error::失败（退出码 $code），出错命令：$BASH_COMMAND"
  push_log "failure"
  exit "$code"
}
trap on_err ERR

log() { printf '\n===== %s =====\n' "$*"; }

# ── 0. 解开仓库根目录的 zip（源码包 / 素材包都可能在这里）────────────────
if [ ! -f project.yml ] || [ ! -f Resources/atlas/normalized.json ]; then
  log "解压仓库根目录的 zip"
  shopt -s nullglob
  for z in *.zip; do
    echo "unzip $z"
    unzip -q -o "$z" -d .
  done
  shopt -u nullglob
fi
ls -la | head -25
test -f project.yml || { echo "!! 解压后仍然没有 project.yml"; false; }

if [ -f Resources/atlas/normalized.json ]; then
  echo "素材来自仓库里的 assets-lite.zip"
  touch .assets-ok
fi

# ── 1. Lua 5.1.5 ─────────────────────────────────────────────────────
log "Lua 源码"
if [ -z "$(ls -A Sources/lua 2>/dev/null || true)" ]; then
  mkdir -p Sources/lua
  if curl -fsSL -o lua.tgz https://www.lua.org/ftp/lua-5.1.5.tar.gz; then
    tar xzf lua.tgz
  else
    echo "lua.org 不通，用 GitHub 镜像"
    curl -fsSL -o lua.tgz https://github.com/lua/lua/archive/refs/tags/v5.1.5.tar.gz
    mkdir -p lua-5.1.5
    tar xzf lua.tgz -C lua-5.1.5 --strip-components=1
  fi
  cp lua-5.1.5/src/*.c lua-5.1.5/src/*.h Sources/lua/ 2>/dev/null || cp lua-5.1.5/*.c lua-5.1.5/*.h Sources/lua/
fi
ls Sources/lua | head -5

# ── 2. 素材（仓库里没有时才去 Release 找）───────────────────────────────
if [ ! -f .assets-ok ]; then
  log "从 Release 取素材"
  rm -rf ipa tmp
  mkdir -p ipa tmp
  gh release list --limit 10 || true
  gh release download assets --pattern '*.ipa' --dir ipa || echo "!! assets 下载失败"
  if ! ls ipa/*.ipa >/dev/null 2>&1; then
    echo "!! assets 里没有 ipa，退到最新 release"
    gh release download --pattern '*.ipa' --dir ipa || true
  fi
  ls -lh ipa 2>/dev/null || true

  n=0
  for f in ipa/*.ipa; do
    [ -e "$f" ] || continue
    n=$((n + 1))
    unzip -q "$f" -d "tmp/$n" || echo "!! $f 解包失败"
  done
  echo "共 $n 个 ipa"

  ASSET_APP=""
  LEGACY_APP=""
  while IFS= read -r app; do
    echo "候选 $app"
    ls "$app" | head -6
    if [ -d "$app/data" ] && [ -d "$app/atlas" ]; then ASSET_APP="$app"; fi
    if [ -f "$app/FargroundsS1-hd.plist" ]; then LEGACY_APP="$app"; fi
  done < <(find tmp -maxdepth 5 -name '*.app' -type d)
  echo "素材包=$ASSET_APP"
  echo "原版包=$LEGACY_APP"

  if [ -n "$ASSET_APP" ] && [ -n "$LEGACY_APP" ]; then
    log "铺素材 + 归一化图集"
    rm -rf Resources/atlas Resources/art Resources/audio Resources/data Resources/fonts
    mkdir -p Resources/atlas Resources/audio/bgm
    cp -R "$ASSET_APP/atlas/." Resources/atlas/
    for d in art audio data fonts; do
      if [ -d "$ASSET_APP/$d" ]; then
        mkdir -p "Resources/$d"
        cp -R "$ASSET_APP/$d/." "Resources/$d/"
      fi
    done
    cp "$LEGACY_APP"/*.caf Resources/audio/bgm/ 2>/dev/null || true
    node Tools/build-atlas.mjs "$LEGACY_APP"
    node Tools/build-frames.mjs
    node Tools/check-data.mjs .
    touch .assets-ok
  else
    echo "::warning::没认出两个包，这次只验证编译"
  fi
fi

# ── 3. 工程与编译 ─────────────────────────────────────────────────────
log "xcodegen"
if ! command -v xcodegen >/dev/null 2>&1; then
  brew install xcodegen
fi
xcodegen generate

log "xcodebuild"
set +e
xcodebuild \
  -project FlyMe2theMoon.xcodeproj \
  -scheme FlyMe2theMoon \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  build
BUILD_OK=$?
set -e
echo "xcodebuild exit=$BUILD_OK"

if [ "$BUILD_OK" -eq 0 ]; then
  log "打包 IPA"
  APP=build/Build/Products/Release-iphoneos/FlyMe2theMoon.app
  rm -rf Payload FlyMe2theMoon-unsigned.ipa
  mkdir -p Payload
  cp -R "$APP" Payload/

  # 先做 ad-hoc 签名：让主程序带上 LC_CODE_SIGNATURE / CodeDirectory，
  # 第三方重签工具（全能签等）再去扩槽/重签就不会报 "embedded 完整性校验失败"。
  TARGET=Payload/FlyMe2theMoon.app
  plutil -convert xml1 "$TARGET/Info.plist" 2>/dev/null || true
  if command -v codesign >/dev/null 2>&1; then
    echo "ad-hoc 签名中…"
    codesign --force --deep --sign - "$TARGET" 2>&1 | tail -5 || echo "!! ad-hoc 签名失败"
    codesign -dv "$TARGET" 2>&1 | head -8 || true
  fi

  zip -qry FlyMe2theMoon-unsigned.ipa Payload
  ls -lh FlyMe2theMoon-unsigned.ipa
fi

# ── 4. 收尾 ───────────────────────────────────────────────────────────
if [ "$BUILD_OK" -ne 0 ]; then
  echo "::error::编译失败"
  push_log "failure"
  exit 1
fi
if [ ! -f .assets-ok ]; then
  push_log "success-no-assets"
  echo "::error::编译通过，但素材缺失（仓库放 assets-lite.zip，或 Release 挂两个 ipa）"
  exit 1
fi
push_log "success"
echo "完成：FlyMe2theMoon-unsigned.ipa"
