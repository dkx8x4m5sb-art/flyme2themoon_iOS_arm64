#!/usr/bin/env bash
# ci/pipeline.sh — 真正的构建逻辑：取素材 → 归一化图集 → 自检 → 编译 → 打包 → 推日志
# 由 .github/workflows/build-from-ipa.yml 调用；需要环境变量 GH_TOKEN（和可选 TAG）。
set -euo pipefail

TAG="${TAG:-assets}"
log() { printf '\n===== %s =====\n' "$*"; }

# 0. 仓库里如果只有 zip（网页上传常见），先解开
if [ ! -f project.yml ]; then
  log "解压仓库根目录的 zip"
  shopt -s nullglob
  for z in *.zip; do
    echo "unzip $z"
    unzip -q -o "$z" -d .
  done
  shopt -u nullglob
fi
ls -la | head -20

# 1. Lua 5.1.5（不进仓库）
log "准备 Lua 源码"
if [ -z "$(ls -A Sources/lua 2>/dev/null || true)" ]; then
  curl -sSLO https://www.lua.org/ftp/lua-5.1.5.tar.gz
  tar xzf lua-5.1.5.tar.gz
  mkdir -p Sources/lua
  cp lua-5.1.5/src/*.c lua-5.1.5/src/*.h Sources/lua/
fi
ls Sources/lua | head -3

# 2. 取素材
log "release 列表"
gh release list --limit 10 || true
echo "--- $TAG ---"
gh release view "$TAG" || echo "（没有 tag 为 $TAG 的 release）"

rm -rf ipa tmp
mkdir -p ipa tmp
gh release download "$TAG" --pattern '*.ipa' --dir ipa \
  || { echo "!! $TAG 下载失败，退到最新 release"; gh release download --pattern '*.ipa' --dir ipa || true; }
if ! ls ipa/*.ipa >/dev/null 2>&1; then
  echo "!! $TAG 里没有 .ipa，改从最新已发布 release 取"
  gh release download --pattern '*.ipa' --dir ipa || true
fi
ls -lh ipa 2>/dev/null || true

log "解包"
n=0
for f in ipa/*.ipa; do
  [ -e "$f" ] || continue
  n=$((n + 1))
  unzip -q "$f" -d "tmp/$n" || echo "!! $f 解包失败"
  echo "$f → tmp/$n"
done
echo "共 $n 个 ipa"

log "认包"
ASSET_APP=""
LEGACY_APP=""
while IFS= read -r app; do
  echo "候选 $app"
  ls "$app" | head -6 | sed 's/^/    /'
  if [ -d "$app/data" ] && [ -d "$app/atlas" ]; then
    ASSET_APP="$app"
    echo "    → 素材包"
  fi
  if [ -f "$app/FargroundsS1-hd.plist" ]; then
    LEGACY_APP="$app"
    echo "    → 1.1 原版"
  fi
done < <(find tmp -maxdepth 5 -name '*.app' -type d)
echo "素材包=$ASSET_APP"
echo "原版包=$LEGACY_APP"

if [ -n "$ASSET_APP" ] && [ -n "$LEGACY_APP" ]; then
  log "铺素材"
  rm -rf Resources/atlas Resources/art Resources/audio Resources/data Resources/fonts
  mkdir -p Resources/atlas Resources/audio/bgm
  cp -R "$ASSET_APP/atlas/." Resources/atlas/
  for d in art audio data fonts; do
    if [ -d "$ASSET_APP/$d" ]; then
      mkdir -p "Resources/$d"
      cp -R "$ASSET_APP/$d/." "Resources/$d/"
    fi
  done
  cp "$LEGACY_APP"/*.caf Resources/audio/bgm/ 2>/dev/null || true

  log "图集归一化 + 数据自检"
  node Tools/build-atlas.mjs "$LEGACY_APP"
  node Tools/build-frames.mjs
  node Tools/check-data.mjs .
  touch .assets-ok
else
  echo "::warning::没认出两个包，跳过素材，只验证编译"
fi

# 3. 编译
log "xcodegen"
brew install xcodegen >/dev/null 2>&1 || brew install xcodegen
xcodegen generate

log "xcodebuild"
set +e
xcodebuild \
  -project FlyMe2theMoon.xcodeproj \
  -scheme FlyMe2theMoon \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  build 2>&1 | tee build-raw.log
BUILD_OK=${PIPESTATUS[0]}
set -e
echo "xcodebuild exit=$BUILD_OK" | tee -a build-raw.log

if [ "$BUILD_OK" -eq 0 ]; then
  log "打包 IPA"
  APP=build/Build/Products/Release-iphoneos/FlyMe2theMoon.app
  rm -rf Payload FlyMe2theMoon-unsigned.ipa
  mkdir -p Payload
  cp -R "$APP" Payload/
  zip -qry FlyMe2theMoon-unsigned.ipa Payload
  ls -lh FlyMe2theMoon-unsigned.ipa
fi

# 4. 把日志推到 ci-logs 分支（方便直接读）
log "发布日志"
{
  echo "# outcome: build=$BUILD_OK assets=$([ -f .assets-ok ] && echo ok || echo missing)"
  echo "# commit: ${GITHUB_SHA:-local}"
  echo "# time: $(date -u +%FT%TZ)"
  echo
  echo "----- 编译错误 -----"
  grep -E "error:|BUILD (SUCCEEDED|FAILED)|The following build commands failed" build-raw.log 2>/dev/null | tail -400 || true
  echo
  echo "----- 编译尾部 -----"
  tail -120 build-raw.log 2>/dev/null || true
} > build-log.md

if git rev-parse --git-dir >/dev/null 2>&1; then
  git config user.name "dsh-ci"
  git config user.email "dsh-ci@users.noreply.github.com"
  git checkout --orphan ci-logs 2>/dev/null || git checkout ci-logs
  git rm -rf --cached . >/dev/null 2>&1 || true
  git add -f build-log.md
  git commit -m "ci: log ${GITHUB_SHA:-local}" || true
  git push origin ci-logs --force || echo "!! 推 ci-logs 失败（权限？）"
fi

if [ "$BUILD_OK" -ne 0 ]; then
  echo "::error::编译失败，看 build-log.md 或 build-raw.log"
  exit 1
fi
if [ ! -f .assets-ok ]; then
  echo "::error::没拿到素材：Release 要有两个已发布的 .ipa 附件"
  exit 1
fi
echo "完成：FlyMe2theMoon-unsigned.ipa"
