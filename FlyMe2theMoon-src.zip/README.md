# 飞向月球 · Fly Me 2 the Moon（64 位重制）

用原版素材重建的 iOS 17+ 原生版本：**SwiftUI + SpriteKit + 内嵌 Lua 5.1**，arm64，60 关完整数据。

原版是 2011 年的 armv7 32 位包（`com.mihoyo.flyme2themoon`，iOS 3.2），在 iOS 11 之后已经无法运行；
这个工程把它在 64 位系统上重新实现，关卡脚本原样沿用。

## 目录

```
App/                     Swift 源码
  Data/                  模型 + 资源加载（JSON / 图集）
  Game/                  LevelScene（渲染/物理/相机）、GameSession
  Lua/                   Lua 5.1 桥（prelude + 27 个脚本 API）
  UI/                    菜单、选关、关卡、设置
  Audio/                 音效与 BGM
  Progress/              存档（通关/星级/剧情标记）
Sources/lua/             Lua 5.1.5 C 源码（不含 io/os/loadlib）
Resources/
  atlas/                 归一化后的图集 PNG + atlas.json / normalized.json
  art/                   对话框表情
  audio/                 70 个音效 + bgm/ 里 6 首 .caf
  data/                  levels/dialogs/role/score/levelselect/dependency/lua/tutorial
  fonts/
Tools/                   素材自检与图集构建（Node，不需要 Xcode）
project.yml              xcodegen 工程描述
.github/workflows/       出未签名 IPA 的流水线
```

## 素材流水线

1. `Tools/build-atlas.mjs <1.1 的 Fly2theMoon.app>`：从**原版 cocos2d plist** 重建图集描述。
   1.7.0 包里那份 `atlas.json` 丢了 `rotated`/`offset`/`sourceSize`，矩形会越界，别用。
2. `Tools/build-frames.mjs`：把旋转帧转正、重新打包（必要时开第二页），产出 `normalized.json`。
   运行时就不用处理旋转，SpriteKit 直接按矩形裁帧。
3. `Tools/check-data.mjs`：60 关 × 22715 个对象全部能解析到贴图或碰撞多边形；
   Lua 引用的对话键、音效、表情逐个核对。**这个必须先过。**

```sh
node Tools/build-atlas.mjs "../私奔到月球FlyMe2theMoon/Payload/Fly2theMoon.app"
node Tools/build-frames.mjs
node Tools/check-data.mjs .
```

## CI：从两个 ipa 出包（推荐）

`.github/workflows/build-from-ipa.yml` 会自己下载并解包原版包、铺素材、归一化图集、自检、编译、打包。

1. 仓库建一个 Release，tag 用 `assets`，上传两个附件：
   - `FlyMe2theMoon_v1.7.0_unsigned.ipa` —— 素材来源（atlas PNG / data / audio / art / fonts）
   - `私奔到月球FlyMe2theMoon.ipa` —— 1.1 原版（cocos2d plist + 6 首 `.caf` BGM）
2. push 到 `main`（或手动 Run workflow），流水线自动跑：
   - 解包 → 认包（找带 `data/` 的素材包、找带 `FargroundsS1-hd.plist` 的原版包）
   - `build-atlas.mjs` → `build-frames.mjs` → `check-data.mjs`
   - xcodegen + xcodebuild → `FlyMe2theMoon-unsigned.ipa`（artifact）
3. 编译日志会推到 `ci-logs` 分支的 `build-log.md`。
   流水线跑在 `macos-13`（Intel）：`macos-14` 现在可能被分到 arm64 runner，而 arm64 macOS runner 只对 public 仓库/付费计划开放，会报 `configuration 'macos-14-arm64-us-default' is not supported`；Intel 上交叉编译 arm64 设备包没问题。
4. Release 里没有 ipa 时仍会跑一遍编译（只验证能编译），最后一步会明确失败并提示缺素材。

## 本地构建

工程没有提交 `.xcodeproj`，用 xcodegen 生成：

```sh
brew install xcodegen
xcodegen generate
xcodebuild -project FlyMe2theMoon.xcodeproj -scheme FlyMe2theMoon \
  -configuration Release -sdk iphoneos \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
```

或者直接跑上面的 `Build from IPA` 流水线（macOS 14 上自动出
`FlyMe2theMoon-unsigned.ipa`）。

产物是**未签名**包：用 AltStore / TrollStore / Sideloadly / 自己的开发者证书签名后才能装。
最低系统 iOS 17.0，只出 arm64。

## 玩法与实现

- **操作**：按住拖动瞄准，松手按"拉弓"力度弹射；角度限制在竖直向上左右各 50°，
  力度在 `role.json` 的 `pushDistance1..2` 之间映射到 `maxF..maxP`。
- **物理**：自写圆 vs 多边形线段碰撞（`edges.json` 的 214 条多边形，按 `StaticObject.seq` 索引），
  重力/阻尼/横向限速都在 `LevelScene.Tuning` 里，随时可调。
- **关卡脚本**：`Resources/data/lua/Level_001..060.lua` 原样执行。脚本会阻塞地调用
  `dialog.show` / `script.delay`，这些用 Lua 协程 yield 交回 Swift 驱动，不改一行脚本。
  引擎在角色死亡/到达月亮时回调全局函数 `onRoleDied` / `onRoleReachedMoon`。
- **渲染**：图层按 `Background/Farground`（视差缩放）→ `Texture` → `DynamicObject` → `Item`
  → `Foreground` 叠；`StaticObject` 只做碰撞不画；`Area` 是到达判定。
- **进度**：通关、星级（阈值来自 `score.json` 的 `svrs`）、`global.setBool` 剧情标记都进 UserDefaults；
  `dependency.json` 决定解锁关系。

## 已知差距（后续迭代）

- 教程图（`game.showTutorialDiagram`）没有素材，先用一行文字提示代替。
- 录制回放（`Rep_rd_*.txt`）没接，演示段用"两秒后当作演示完成"的简化处理。
- 角色贴图按裁剪帧画，`offset` 只用于定位，个别帧可能有 1–2px 偏移。
- 物理手感是按 `role.json` 常量推的，没有原版可比对，需要真机试玩后调 `Tuning`。

## 版权

素材来自原版游戏，版权归 miHoYo。本工程只做本机自用与备份，不对外分发。
