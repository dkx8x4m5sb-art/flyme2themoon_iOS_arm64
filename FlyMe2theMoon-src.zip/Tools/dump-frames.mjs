// dump-frames.mjs — 把若干帧从图集里切出来拼成一张对照图，用来看旋转方向/裁剪是否正确。
// 用法：node Tools/dump-frames.mjs <sheet> <frameName>[,<frameName>...] <输出 png> [--rotate]
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { decodePng, encodePng } from './png.mjs'

const [sheet, names, outPath, flag] = process.argv.slice(2)
if (!sheet || !names || !outPath) {
  console.error('用法：node Tools/dump-frames.mjs <sheet> <帧名,帧名> <输出 png> [--rotate]')
  process.exit(2)
}
const ROOT = join('Resources', 'atlas')
const useNorm = process.argv.includes('--normalized')
const atlas = JSON.parse(readFileSync(join(ROOT, useNorm ? 'normalized.json' : 'atlas.json'), 'utf8'))
const def = atlas.sheets[sheet]
if (!def) {
  console.error(`没有图集 ${sheet}`)
  process.exit(2)
}
const pages = def.pages || [{ image: def.image }]
const imgs = pages.map((pg) => decodePng(readFileSync(join(ROOT, pg.image))))
const list = names.split(',')
const pad = 8
const cells = []
let width = pad
let height = pad
for (const name of list) {
  const f = def.frames[name]
  if (!f) {
    console.error(`没有帧 ${name}`)
    process.exit(2)
  }
  const cellW = f.rotated ? f.h : f.w
  const cellH = f.rotated ? f.w : f.h
  cells.push({ name, f, cellW, cellH, x: width, page: f.p || 0 })
  width += cellW + pad
  height = Math.max(height, cellH + pad * 2)
}
const canvas = Buffer.alloc(width * height * 4)
const put = (dstX, dstY, r, g, b, a) => {
  const o = (dstY * width + dstX) * 4
  canvas[o] = r
  canvas[o + 1] = g
  canvas[o + 2] = b
  canvas[o + 3] = a
}
for (const cell of cells) {
  const { f } = cell
  const img = imgs[cell.page]
  // 从贴图上取出旋转后的子图：宽 h、高 w
  const sw = f.rotated ? f.h : f.w
  const sh = f.rotated ? f.w : f.h
  const tmp = Buffer.alloc(sw * sh * 4)
  for (let y = 0; y < sh; y += 1) {
    for (let x = 0; x < sw; x += 1) {
      const sx = f.x + x
      const sy = f.y + y
      const so = (sy * img.width + sx) * 4
      const to = (y * sw + x) * 4
      tmp[to] = img.data[so]
      tmp[to + 1] = img.data[so + 1]
      tmp[to + 2] = img.data[so + 2]
      tmp[to + 3] = img.data[so + 3]
    }
  }
  // 旋转帧：子图顺时针转 90°（cocos2d 约定，看结果验证）
  const cw = cell.cellW
  const ch = cell.cellH
  const outCell = Buffer.alloc(cw * ch * 4)
  for (let y = 0; y < ch; y += 1) {
    for (let x = 0; x < cw; x += 1) {
      let sx
      let sy
      if (f.rotated) {
        // 逆时针转回：out(x,y) ← tmp(y, sh-1-x)? 用顺时针/逆时针两种都试，靠 --rotate 开关
        if (flag === '--rotate') {
          sx = y
          sy = ch - 1 - x
        } else {
          sx = sw - 1 - y
          sy = x
        }
      } else {
        sx = x
        sy = y
      }
      const so = (sy * sw + sx) * 4
      const o = (y * cw + x) * 4
      outCell[o] = tmp[so]
      outCell[o + 1] = tmp[so + 1]
      outCell[o + 2] = tmp[so + 2]
      outCell[o + 3] = tmp[so + 3]
    }
  }
  for (let y = 0; y < ch; y += 1) {
    for (let x = 0; x < cw; x += 1) {
      const o = (y * cw + x) * 4
      put(cell.x + x, pad + y, outCell[o], outCell[o + 1], outCell[o + 2], outCell[o + 3])
    }
  }
}
writeFileSync(outPath, encodePng(width, height, canvas))
console.log(`写出 ${outPath}（${width}x${height}），帧：${cells.map((c) => c.name).join(', ')}`)
