// check-data.mjs — 素材/数据自检：不联网、不依赖 Xcode。
// 用法：node Tools/check-data.mjs [项目根] [--verbose]
import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { join, resolve } from 'node:path'

const root = resolve(process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : '.')
const RES = join(root, 'Resources')
const verbose = process.argv.includes('--verbose')
const problems = []
const stats = {}
const fail = (m) => problems.push(m)
const readJson = (p) => JSON.parse(readFileSync(join(RES, p), 'utf8'))

function pngSize(buf) {
  if (buf.toString('latin1', 1, 4) !== 'PNG') throw new Error('不是 PNG')
  const w = buf.readUInt32BE(16)
  const h = buf.readUInt32BE(20)
  if (!w || !h || w > 20000 || h > 20000) throw new Error(`可疑尺寸 ${w}x${h}`)
  return [w, h]
}

// ── 图集 ────────────────────────────────────────────────────────────────
const atlas = readJson('atlas/normalized.json')
const sheets = new Map()
for (const [sheet, def] of Object.entries(atlas.sheets)) {
  const pages = def.pages || [{ image: def.image, size: def.size }]
  for (const page of pages) {
    const file = join(RES, 'atlas', page.image)
    if (!existsSync(file)) { fail(`图集缺贴图：atlas/${page.image}`); continue }
    const [w, h] = pngSize(readFileSync(file))
    if (w !== page.size[0] || h !== page.size[1]) fail(`${page.image} 尺寸 ${w}x${h} 与描述 ${page.size} 不一致`)
  }
  const frames = new Map(Object.entries(def.frames))
  sheets.set(sheet, { frames })
  for (const [name, f] of frames) {
    const needW = f.x + f.w
    const needH = f.y + f.h
    const page = pages[f.p || 0]
    if (!page) { fail(`${sheet}/${name} 页码 ${f.p} 不存在`); continue }
    if (needW > page.size[0] || needH > page.size[1]) fail(`图集 ${sheet} 帧 ${name} 越界`)
  }
}
stats['图集'] = `${sheets.size} 张 / ${[...sheets.values()].reduce((n, s) => n + s.frames.size, 0)} 帧`

// ── 关卡 ────────────────────────────────────────────────────────────────
const levels = readJson('data/levels.json')
const edges = readJson('data/edges.json')
const dialogs = readJson('data/dialogs.json')
const role = readJson('data/role.json')
const score = readJson('data/score.json')
const levelselect = readJson('data/levelselect.json')
const dependency = readJson('data/dependency.json')

const LAYER_FRAME = {
  Background: (seq) => `Background_${String(seq).padStart(3, '0')}.png`,
  Farground: (seq) => `Farground_${String(seq).padStart(3, '0')}.png`,
  Texture: (seq) => `Texture_${String(seq).padStart(3, '0')}.png`,
  Foreground: (seq) => `Foreground_${String(seq).padStart(3, '0')}.png`,
  Item: (seq) => `Item_${String(seq).padStart(3, '0')}`,
  DynamicObject: (seq) => `DynamicObject_${String(seq).padStart(3, '0')}`,
}
// 图层 → 图集
const LAYER_SHEET = {
  Background: (suite) => `FargroundsS${suite}-hd`,
  Farground: (suite) => `FargroundsS${suite}-hd`,
  Texture: (suite) => `TextureS${suite}-hd`,
  Foreground: (suite) => `TextureS${suite}-hd`,
  Item: () => 'DynamicObjectsLite-hd',
  DynamicObject: () => 'DynamicObjectsLite-hd',
}

function resolveFrames(sheet, base) {
  const frames = sheets.get(sheet)?.frames
  if (!frames) return []
  if (frames.has(base)) return [base]
  const key = base.replace(/\.png$/, '')
  return [...frames.keys()].filter((n) => n === key || n.startsWith(`${key}/`))
}

const levelIds = Object.keys(levels)
  .map(Number)
  .sort((a, b) => a - b)
stats['关卡'] = `${levelIds.length} 关`

let objCount = 0
let missingFrames = 0
let missingEdges = 0
const seqSeen = new Set()

for (const id of levelIds) {
  const lv = levels[String(id)]
  if (!lv) {
    fail(`关卡 ${id} 数据缺失`)
    continue
  }
  if (!Array.isArray(lv.born) || lv.born.length !== 2) fail(`关卡 ${id} 缺出生点 born`)
  if (![1, 2, 3, 4].includes(lv.suite)) fail(`关卡 ${id} suite 异常：${lv.suite}`)
  if (!Array.isArray(lv.layers)) {
    fail(`关卡 ${id} 没有 layers`)
    continue
  }
  for (const layer of lv.layers) {
    for (const obj of layer.objs || []) {
      objCount += 1
      seqSeen.add(`${layer.name}:${obj.seq}`)
      if (layer.name === 'StaticObject') {
        if (!edges[String(obj.seq)]) {
          missingEdges += 1
          fail(`关卡 ${id} StaticObject seq=${obj.seq} 没有碰撞多边形`)
        }
        continue
      }
      if (layer.name === 'Area') continue
      const nameFn = LAYER_FRAME[layer.name]
      const sheetFn = LAYER_SHEET[layer.name]
      if (!nameFn || !sheetFn) {
        fail(`关卡 ${id} 未知图层 ${layer.name}`)
        continue
      }
      const sheet = sheetFn(lv.suite)
      if (layer.name === 'Background' && obj.seq === 1) continue // 原版用代码画天空渐变
      const hits = resolveFrames(sheet, nameFn(obj.seq))
      if (!hits.length) {
        missingFrames += 1
        if (missingFrames <= 10) fail(`关卡 ${id} ${layer.name} seq=${obj.seq} → ${nameFn(obj.seq)} 不在 ${sheet}`)
      }
    }
  }
}
stats['对象'] = `${objCount} 个 / ${seqSeen.size} 种 (图层:seq)`
stats['缺口'] = `贴图 ${missingFrames} · 碰撞 ${missingEdges}`

// ── 碰撞多边形 ──────────────────────────────────────────────────────────
for (const [k, poly] of Object.entries(edges)) {
  if (!Array.isArray(poly) || poly.length < 3) {
    fail(`edges[${k}] 不是多边形`)
    continue
  }
  for (const p of poly) {
    if (!Array.isArray(p) || p.length < 2 || !p.every(Number.isFinite)) {
      fail(`edges[${k}] 顶点异常`)
      break
    }
  }
}

// ── 脚本 ────────────────────────────────────────────────────────────────
const luaDir = join(RES, 'data', 'lua')
const luaFiles = existsSync(luaDir) ? readdirSync(luaDir).filter((f) => f.endsWith('.lua')) : []
if (luaFiles.length !== levelIds.length) fail(`脚本 ${luaFiles.length} 个，关卡 ${levelIds.length} 个`)
stats['脚本'] = `${luaFiles.length} 个`

const dialogIndex = new Map()
for (const list of Object.values(dialogs)) for (const line of list) if (line?.k) dialogIndex.set(line.k, line)
stats['对话'] = `${dialogIndex.size} 条`

const soundFiles = new Set(readdirSync(join(RES, 'audio')).filter((f) => f.endsWith('.wav')).map((f) => f.replace(/\.wav$/, '')))
const faceFiles = new Set(
  readdirSync(join(RES, 'art')).filter((f) => f.startsWith('face')).map((f) => f.replace(/\.png$/, '')),
)
const missingDialog = new Set()
const missingSound = new Set()
const missingFace = new Set()
const apiCalls = new Map()

for (const file of luaFiles) {
  const src = readFileSync(join(luaDir, file), 'utf8')
  for (const m of src.matchAll(/\b([a-z][A-Za-z0-9_]*)\.([a-zA-Z][A-Za-z0-9_]*)\s*\(/g)) {
    const key = `${m[1]}.${m[2]}`
    apiCalls.set(key, (apiCalls.get(key) || 0) + 1)
  }
  for (const m of src.matchAll(/dialog\.(?:show|showMinTime|showFixedTime)\(\s*["']([^"']+)["']/g))
    if (!dialogIndex.has(m[1])) missingDialog.add(m[1])
  for (const m of src.matchAll(/sound\.play\(\s*["']([^"']+)["']/g))
    if (!soundFiles.has(m[1])) missingSound.add(m[1])
  for (const m of src.matchAll(/\b(face[A-Z][A-Za-z]+)\b/g)) if (!faceFiles.has(m[1])) missingFace.add(m[1])
}
if (missingDialog.size) fail(`缺对话键 ${missingDialog.size} 个：${[...missingDialog].slice(0, 8).join(', ')}`)
if (missingSound.size) fail(`缺音效 ${missingSound.size} 个：${[...missingSound].join(', ')}`)
if (missingFace.size) fail(`缺表情 ${missingFace.size} 个：${[...missingFace].join(', ')}`)
stats['Lua API'] = `${apiCalls.size} 个方法`

// ── 元数据 ──────────────────────────────────────────────────────────────
for (const id of levelIds) {
  if (!levelselect.levels?.[String(id)]) fail(`levelselect 缺第 ${id} 关`)
  if (!score.svrs?.[String(id)]) fail(`score.svrs 缺第 ${id} 关`)
  if (!dependency[String(id)]) fail(`dependency 缺第 ${id} 关`)
}
stats['物理参数'] = `${Object.keys(role).length} 项`

// ── 输出 ────────────────────────────────────────────────────────────────
console.log('== 素材自检 ==')
for (const [k, v] of Object.entries(stats)) console.log(`  ${k}: ${v}`)
if (verbose) {
  console.log('\n脚本调用的 API：')
  for (const [k, v] of [...apiCalls].sort((a, b) => b[1] - a[1])) console.log(`  ${String(v).padStart(4)}  ${k}`)
}
if (problems.length) {
  console.log(`\n问题 ${problems.length} 条：`)
  for (const p of problems.slice(0, 40)) console.log(`  · ${p}`)
  if (problems.length > 40) console.log(`  … 还有 ${problems.length - 40} 条`)
  process.exitCode = 1
} else {
  console.log('\n全部通过')
}
