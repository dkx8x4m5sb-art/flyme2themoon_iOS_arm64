// build-atlas.mjs — 从 1.1 原版的 cocos2d plist 生成我们自己的图集描述。
// 背景：1.7.0 包里那份 atlas.json 丢了 rotated/offset/sourceSize，矩形越界；
// 原版 plist 是权威数据，PNG 用 1.7.0 已解码好的那张（尺寸与 plist 的 metadata.size 一致）。
//
// 用法：node Tools/build-atlas.mjs <1.1 的 Fly2theMoon.app 目录>
import { readFileSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { parseBplist } from './bplist.mjs'

const SRC = process.argv[2]
if (!SRC) {
  console.error('用法：node Tools/build-atlas.mjs <1.1 的 Fly2theMoon.app 目录>')
  process.exit(2)
}

const SHEETS = [
  'CharActions-hd',
  'DynamicObjectsLite-hd',
  'FargroundsS1-hd',
  'FargroundsS2-hd',
  'FargroundsS3-hd',
  'FargroundsS4-hd',
  'TextureS1-hd',
  'TextureS2-hd',
  'TextureS3-hd',
  'TextureS4-hd',
]

const OUT = join('Resources', 'atlas')

function rect(str) {
  const m = /^\{\{(-?[\d.]+),(-?[\d.]+)\},\{(-?[\d.]+),(-?[\d.]+)\}\}$/.exec(String(str).trim())
  if (!m) throw new Error(`解析矩形失败：${str}`)
  return { x: +m[1], y: +m[2], w: +m[3], h: +m[4] }
}

function point(str) {
  const m = /^\{(-?[\d.]+),(-?[\d.]+)\}$/.exec(String(str).trim())
  if (!m) throw new Error(`解析坐标失败：${str}`)
  return { x: +m[1], y: +m[2] }
}

const out = { sheets: {} }
let totalFrames = 0
let overflow = 0

for (const sheet of SHEETS) {
  const pl = parseBplist(readFileSync(join(SRC, `${sheet}.plist`)))
  const size = /(\d+),(\d+)/.exec(String(pl.metadata?.size || ''))
  const sheetW = Number(size?.[1] ?? 0)
  const sheetH = Number(size?.[2] ?? 0)
  const image = `${sheet}.png`
  const bytes = statSync(join(OUT, image)).size
  const frames = {}
  let rotated = 0
  let trimmed = 0

  for (const [name, f] of Object.entries(pl.frames || {})) {
    const r = rect(f.frame)
    const src = point(f.sourceSize)
    const cr = f.sourceColorRect ? rect(f.sourceColorRect) : { x: 0, y: 0 }
    const off = f.offset ? point(f.offset) : { x: 0, y: 0 }
    // 旋转帧在贴图上占的是 h 宽、w 高
    const needW = r.x + (f.rotated ? r.h : r.w)
    const needH = r.y + (f.rotated ? r.w : r.h)
    if (needW > sheetW || needH > sheetH) {
      overflow += 1
      console.error(`  ✗ ${sheet}/${name} 越界：需要 ${needW}x${needH}，贴图 ${sheetW}x${sheetH}`)
    }
    if (f.rotated) rotated += 1
    if (cr.x !== 0 || cr.y !== 0 || src.x !== r.w || src.y !== r.h) trimmed += 1
    frames[name] = {
      x: r.x,
      y: r.y,
      w: r.w,
      h: r.h,
      rotated: !!f.rotated,
      ox: off.x,
      oy: off.y,
      sw: src.x,
      sh: src.y,
      cx: cr.x,
      cy: cr.y,
    }
  }

  out.sheets[sheet] = { image, size: [sheetW, sheetH], bytes, frames }
  totalFrames += Object.keys(frames).length
  console.log(
    `${sheet}: ${Object.keys(frames).length} 帧（旋转 ${rotated}、裁剪 ${trimmed}）` +
      `，${sheetW}x${sheetH}，PNG ${(bytes / 1048576).toFixed(1)} MB`,
  )
}

writeFileSync(join(OUT, 'atlas.json'), `${JSON.stringify(out)}\n`)
console.log(`\n写出 ${join(OUT, 'atlas.json')}：${SHEETS.length} 张图 / ${totalFrames} 帧，越界 ${overflow}`)
if (overflow) process.exitCode = 1
