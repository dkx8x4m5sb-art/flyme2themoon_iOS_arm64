// bplist.mjs — 最小二进制 plist（bplist00）解析器，够读 Info.plist 用。
// 支持：null/bool/int/real/date/data/ascii/utf16/uid/array/dict。
export function parseBplist(buf) {
  if (buf.subarray(0, 8).toString('latin1') !== 'bplist00') throw new Error('不是 bplist00')
  const tail = buf.subarray(buf.length - 32)
  const offsetSize = tail[6]
  const refSize = tail[7]
  const numObjects = Number(tail.readBigUInt64BE(8))
  const top = Number(tail.readBigUInt64BE(16))
  const tableOff = Number(tail.readBigUInt64BE(24))
  const offsets = []
  for (let i = 0; i < numObjects; i += 1) offsets.push(readUInt(buf, tableOff + i * offsetSize, offsetSize))

  function readUInt(b, off, size) {
    let v = 0
    for (let i = 0; i < size; i += 1) v = v * 256 + b[off + i]
    return v
  }

  function lengthAt(off, info) {
    if (info !== 0xf) return { length: info, next: off + 1 }
    const marker = buf[off + 1]
    const size = 2 ** (marker & 0xf)
    return { length: readUInt(buf, off + 2, size), next: off + 2 + size }
  }

  function object(ref, depth = 0) {
    if (depth > 64) return null
    const off = offsets[ref]
    if (off === undefined) return null
    const marker = buf[off]
    const type = marker >> 4
    const info = marker & 0xf
    if (type === 0x0) {
      if (marker === 0x08) return false
      if (marker === 0x09) return true
      return null
    }
    if (type === 0x1) {
      const size = 2 ** info
      return readUInt(buf, off + 1, size)
    }
    if (type === 0x2) {
      const size = 2 ** info
      if (size === 4) return buf.readFloatBE(off + 1)
      return buf.readDoubleBE(off + 1)
    }
    if (type === 0x3) {
      const seconds = buf.readDoubleBE(off + 1)
      return new Date(Date.UTC(2001, 0, 1) + seconds * 1000)
    }
    if (type === 0x4) {
      const { length, next } = lengthAt(off, info)
      return buf.subarray(next, next + length)
    }
    if (type === 0x5) {
      const { length, next } = lengthAt(off, info)
      return buf.toString('latin1', next, next + length)
    }
    if (type === 0x6) {
      const { length, next } = lengthAt(off, info)
      const chars = []
      for (let i = 0; i < length; i += 1) chars.push(String.fromCharCode(buf.readUInt16BE(next + i * 2)))
      return chars.join('')
    }
    if (type === 0x8) {
      return readUInt(buf, off + 1, info + 1)
    }
    if (type === 0xa) {
      const { length, next } = lengthAt(off, info)
      const out = []
      for (let i = 0; i < length; i += 1) out.push(object(readUInt(buf, next + i * refSize, refSize), depth + 1))
      return out
    }
    if (type === 0xd) {
      const { length, next } = lengthAt(off, info)
      const out = {}
      for (let i = 0; i < length; i += 1) {
        const keyRef = readUInt(buf, next + i * refSize, refSize)
        const valRef = readUInt(buf, next + length * refSize + i * refSize, refSize)
        const key = object(keyRef, depth + 1)
        out[String(key)] = object(valRef, depth + 1)
      }
      return out
    }
    return null
  }

  return object(top)
}
