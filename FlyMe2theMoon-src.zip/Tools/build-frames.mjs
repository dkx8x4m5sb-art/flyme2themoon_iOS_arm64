// build-frames.mjs — 图集归一化：把旋转帧转正、重新打包（必要时开第二页）。
// 运行时就不需要处理 rotated，SpriteKit 直接按矩形裁帧。
//
// 用法：node Tools/build-frames.mjs
// 输入：Resources/atlas/atlas.json + 同名 PNG（首次运行会把 PNG 备份成 *.orig.png）
// 输出：Resources/atlas/normalized.json + <sheet>.png / <sheet>-p1.png …
import { copyFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { decodePng, encodePng } from './png.mjs'

const ATLAS = join('Resources', 'atlas')
const atlas = JSON.parse(readFileSync(join(ATLAS, 'atlas.json'), 'utf8'))
const PAD = 1

const out = { sheets: {} }
let unrotated = 0
let failed = 0

for (const [sheet, def] of Object.entries(atlas.sheets)) {
  const srcPath = join(ATLAS, def.image)
  const backup = join('.cache', 'atlas-orig', def.image.replace(/\.png$/, '.orig.png'))
  if (!existsSync(backup)) { require('node:fs').mkdirSync(join('.cache', 'atlas-orig'), { recursive: true }); copyFileSync(srcPath, backup) }
  const img = decodePng(readFileSync(backup))
  const [W, H] = def.size

  const frames = []
  for (const [name, f] of Object.entries(def.frames)) {
    const w = f.w
    const h = f.h
    const px = Buffer.alloc(w * h * 4)
    if (f.rotated) {
      const sw = f.h
      for (let y = 0; y < h; y += 1) {
        for (let x = 0; x < w; x += 1) {
          const u = sw - 1 - y
          const v = x
          const so = ((f.y + v) * img.width + (f.x + u)) * 4
          const to = (y * w + x) * 4
          px[to] = img.data[so]
          px[to + 1] = img.data[so + 1]
          px[to + 2] = img.data[so + 2]
          px[to + 3] = img.data[so + 3]
        }
      }
      unrotated += 1
    } else {
      for (let y = 0; y < h; y += 1) {
        const so = ((f.y + y) * img.width + f.x) * 4
        img.data.copy(px, y * w * 4, so, so + w * 4)
      }
    }
    frames.push({ name, w, h, px, meta: f })
  }

  frames.sort((a, b) => b.h - a.h || b.w - a.w)
  const pages = []
  let pending = frames
  for (let page = 0; pending.length && page < 8; page += 1) {
    const canvas = Buffer.alloc(W * H * 4)
    const placed = new Map()
    const rest = []
    let shelfX = PAD
    let shelfY = PAD
    let shelfH = 0
    for (const fr of pending) {
      if (shelfX + fr.w + PAD > W) {
        shelfY += shelfH + PAD
        shelfX = PAD
        shelfH = 0
      }
      if (shelfY + fr.h + PAD > H) {
        rest.push(fr)
        continue
      }
      for (let y = 0; y < fr.h; y += 1) {
        const so = y * fr.w * 4
        fr.px.copy(canvas, ((shelfY + y) * W + shelfX) * 4, so, so + fr.w * 4)
      }
      placed.set(fr.name, { x: shelfX, y: shelfY, w: fr.w, h: fr.h })
      shelfX += fr.w + PAD
      shelfH = Math.max(shelfH, fr.h)
    }
    if (!placed.size) break
    const image = page === 0 ? def.image : def.image.replace(/\.png$/, `-p${page}.png`)
    writeFileSync(join(ATLAS, image), encodePng(W, H, canvas))
    pages.push({ image, size: [W, H], placed })
    pending = rest
  }
  if (pending.length) failed += 1

  const framesOut = {}
  for (const fr of frames) {
    for (let pi = 0; pi < pages.length; pi += 1) {
      const pos = pages[pi].placed.get(fr.name)
      if (!pos) continue
      framesOut[fr.name] = {
        x: pos.x,
        y: pos.y,
        w: pos.w,
        h: pos.h,
        p: pi,
        rotated: false,
        ox: fr.meta.ox,
        oy: fr.meta.oy,
        sw: fr.meta.sw,
        sh: fr.meta.sh,
        cx: fr.meta.cx,
        cy: fr.meta.cy,
      }
      break
    }
  }
  out.sheets[sheet] = { pages: pages.map((pg) => ({ image: pg.image, size: pg.size })), frames: framesOut }
  console.log(`${sheet}: ${frames.length} 帧 → ${pages.length} 页（${pending.length ? '有放不下' : '全部放下'}）`)
}

writeFileSync(join(ATLAS, 'normalized.json'), `${JSON.stringify(out)}\n`)
console.log(`\n写出 normalized.json：${Object.keys(out.sheets).length} 组，转正 ${unrotated} 帧，失败 ${failed}`)
if (failed) process.exitCode = 1
