//
//  AudioEngine.swift
//  音效用 AVAudioPlayer 池；BGM 直接播原版 .caf（iOS 原生支持 CAF/IMA4）。
//

import AVFoundation
import Foundation

final class AudioEngine {
    static let shared = AudioEngine()

    private var players: [AVAudioPlayer] = []
    private var bgm: AVAudioPlayer?
    private var cache: [String: Data] = [:]
    private let root: URL

    var sfxEnabled = true
    var bgmEnabled = true
    private var currentBGM = ""

    private init() {
        root = Bundle.main.resourceURL!.appendingPathComponent("Resources", isDirectory: true)
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.ambient, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)
    }

    func play(sound id: String) {
        guard sfxEnabled else { return }
        let url = root.appendingPathComponent("audio/\(id).wav")
        guard let player = try? AVAudioPlayer(contentsOf: url) else { return }
        player.prepareToPlay()
        player.play()
        players.append(player)
        if players.count > 12 {
            players.removeAll { !$0.isPlaying }
            if players.count > 20 { players.removeFirst(players.count - 20) }
        }
    }

    func playMusic(_ name: String, loop: Bool = true) {
        guard bgmEnabled else { return }
        if currentBGM == name, let bgm, bgm.isPlaying { return }
        let url = root.appendingPathComponent("audio/bgm/\(name).caf")
        guard let player = try? AVAudioPlayer(contentsOf: url) else { return }
        player.numberOfLoops = loop ? -1 : 0
        player.volume = 0.7
        player.play()
        bgm?.stop()
        bgm = player
        currentBGM = name
    }

    func stopMusic() {
        bgm?.stop()
        bgm = nil
        currentBGM = ""
    }

    /// 每关按 suite 选一首 BGM（原版没有公开对应表，这里按 suite 固定映射）
    func musicForSuite(_ suite: Int) -> String {
        switch suite {
        case 1: return "MoonTrip"
        case 2: return "SkyTunnel"
        case 3: return "SpiralofAdventure"
        default: return "SymphonyofRush"
        }
    }
}
