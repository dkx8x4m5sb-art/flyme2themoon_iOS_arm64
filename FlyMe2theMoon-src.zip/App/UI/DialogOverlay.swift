//
//  DialogOverlay.swift
//  底部对话框：头像 + 台词，点一下继续。
//

import SwiftUI

struct DialogOverlay: View {
    let dialog: DialogState
    var onTap: () -> Void

    var body: some View {
        VStack {
            Spacer()
            HStack(alignment: .bottom, spacing: 12) {
                if let image = GameData.shared.faceImage(dialog.face) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 96, height: 96)
                        .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.08)))
                }
                VStack(alignment: .leading, spacing: 6) {
                    Text(dialog.text)
                        .font(.system(size: 15))
                        .foregroundStyle(.white)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("点一下继续")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.5))
                }
                Spacer(minLength: 0)
            }
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 18)
                    .fill(Color.black.opacity(0.72))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.12), lineWidth: 1))
            )
            .padding(.horizontal, 16)
            .padding(.bottom, 26)
            .contentShape(Rectangle())
            .onTapGesture(perform: onTap)
        }
    }
}

struct ResultOverlay: View {
    let passed: Bool
    let time: Double
    let level: Int
    var onRetry: () -> Void
    var onExit: () -> Void

    var body: some View {
        ZStack {
            Color.black.opacity(0.6).ignoresSafeArea()
            VStack(spacing: 16) {
                Text(passed ? "到达月球" : "再试一次")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text(String(format: "用时 %.2fs", time))
                    .font(.system(size: 15, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.75))
                if passed {
                    HStack(spacing: 6) {
                        ForEach(0..<3, id: \.self) { i in
                            Image(systemName: i < ProgressStore.shared.stars(level) ? "star.fill" : "star")
                                .foregroundStyle(.yellow)
                        }
                    }
                }
                HStack(spacing: 12) {
                    Button("重来", action: onRetry)
                        .buttonStyle(.bordered)
                    Button(passed ? "返回选关" : "退出", action: onExit)
                        .buttonStyle(.borderedProminent)
                }
                .tint(.white)
            }
            .padding(26)
            .background(RoundedRectangle(cornerRadius: 22).fill(Color(white: 0.12)))
        }
    }
}
