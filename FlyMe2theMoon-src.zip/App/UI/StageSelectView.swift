//
//  StageSelectView.swift
//  60 关网格：锁住的关不能点，通关显示星星与最佳成绩。
//

import SwiftUI

struct StageSelectView: View {
    var onPick: (Int) -> Void

    @State private var unlocked: Set<Int> = []
    @State private var stars: [Int: Int] = [:]
    @State private var best: [Int: Double] = [:]

    private let columns = [GridItem(.adaptive(minimum: 66), spacing: 12)]

    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(GameData.shared.levelIDs, id: \.self) { id in
                    let open = unlocked.contains(id)
                    Button {
                        if open { onPick(id) }
                    } label: {
                        VStack(spacing: 4) {
                            Text("\(id)")
                                .font(.system(size: 22, weight: .bold, design: .rounded))
                            HStack(spacing: 1) {
                                ForEach(0..<3, id: \.self) { i in
                                    Image(systemName: i < (stars[id] ?? 0) ? "star.fill" : "star")
                                        .font(.system(size: 8))
                                        .foregroundStyle(i < (stars[id] ?? 0) ? .yellow : .white.opacity(0.25))
                                }
                            }
                        }
                        .frame(width: 66, height: 66)
                        .background(
                            RoundedRectangle(cornerRadius: 14)
                                .fill(open ? Color.white.opacity(0.12) : Color.white.opacity(0.04))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(open ? Color.accentColor.opacity(0.6) : Color.white.opacity(0.08), lineWidth: 1)
                        )
                        .foregroundStyle(open ? .white : .white.opacity(0.25))
                    }
                    .disabled(!open)
                }
            }
            .padding()
        }
        .background(Color(red: 0.05, green: 0.06, blue: 0.12).ignoresSafeArea())
        .navigationTitle("选关")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: refresh)
    }

    private func refresh() {
        unlocked = ProgressStore.shared.unlockedLevels()
        var s: [Int: Int] = [:]
        var b: [Int: Double] = [:]
        for id in GameData.shared.levelIDs {
            s[id] = ProgressStore.shared.stars(id)
            b[id] = ProgressStore.shared.bestTime(id)
        }
        stars = s
        best = b
    }
}
