//
//  LevelScreen.swift
//  SpriteKit 画面 + HUD + 对话框 + 通关面板。
//

import SpriteKit
import SwiftUI

struct LevelScreen: View {
    let levelID: Int
    @StateObject private var session: GameSession
    @Environment(\.dismiss) private var dismiss

    init(levelID: Int) {
        self.levelID = levelID
        _session = StateObject(wrappedValue: GameSession(levelID: levelID))
    }

    var body: some View {
        ZStack {
            SpriteView(scene: session.scene, options: [.ignoresSiblingOrder])
                .ignoresSafeArea()

            // HUD
            VStack {
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(.headline)
                            .padding(10)
                            .background(Circle().fill(.black.opacity(0.35)))
                            .foregroundStyle(.white)
                    }
                    Spacer()
                    VStack(spacing: 2) {
                        Text("STAGE \(levelID)")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white.opacity(0.9))
                        Text(String(format: "%.2fs", session.time))
                            .font(.system(size: 15, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.white)
                    }
                    Spacer()
                    Text(session.fails > 0 ? "失败 \(session.fails)" : "")
                        .font(.caption)
                        .foregroundStyle(.orange)
                        .frame(width: 60, alignment: .trailing)
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                Spacer()
            }

            if let dialog = session.dialog {
                DialogOverlay(dialog: dialog) {
                    session.advanceDialog()
                }
            }

            if session.tutorial > 0 {
                VStack {
                    Spacer()
                    Text("长按拖动 → 松手起飞，飞到月亮上")
                        .font(.subheadline)
                        .padding(12)
                        .background(Capsule().fill(.black.opacity(0.6)))
                        .foregroundStyle(.white)
                        .padding(.bottom, 120)
                }
                .allowsHitTesting(false)
            }

            if let result = session.result {
                ResultOverlay(passed: result.passed, time: result.time, level: levelID) {
                    session.restartLevel()
                } onExit: {
                    dismiss()
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { session.scene.onTutorial = { session.showTutorialDiagram($0) } }
    }
}
