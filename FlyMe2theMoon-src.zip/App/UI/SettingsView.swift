//
//  SettingsView.swift
//  音效 / 音乐开关 + 存档与素材说明。
//

import SwiftUI

struct SettingsView: View {
    @State private var sfx = AudioEngine.shared.sfxEnabled
    @State private var bgm = AudioEngine.shared.bgmEnabled
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("声音") {
                    Toggle("音效", isOn: $sfx)
                        .onChange(of: sfx) { _, value in AudioEngine.shared.sfxEnabled = value }
                    Toggle("背景音乐", isOn: $bgm)
                        .onChange(of: bgm) { _, value in
                            AudioEngine.shared.bgmEnabled = value
                            if !value { AudioEngine.shared.stopMusic() }
                        }
                }
                Section("关于") {
                    LabeledContent("版本", value: "1.7.0（64 位重制）")
                    LabeledContent("素材", value: "原版 HD 图集 + 70 个音效 + 6 首 BGM")
                    LabeledContent("引擎", value: "SpriteKit + Lua 5.1")
                }
                Section("说明") {
                    Text("这是用原版素材重建的版本，只在本机自用；素材版权归 miHoYo。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("设置")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }
}
