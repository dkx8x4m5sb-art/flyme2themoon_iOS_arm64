//
//  RootView.swift
//  主菜单 → 选关 → 关卡（推整页）。
//

import SwiftUI

struct RootView: View {
    @State private var path: [Route] = []
    @State private var showSettings = false

    enum Route: Hashable {
        case stageSelect
        case level(Int)
    }

    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                LinearGradient(
                    colors: [Color(red: 0.05, green: 0.06, blue: 0.12), Color(red: 0.12, green: 0.09, blue: 0.20)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 26) {
                    Spacer()
                    Text("飞向月球")
                        .font(.system(size: 46, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Fly Me 2 the Moon · 64 位重制")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.6))
                    Spacer()

                    Button {
                        path.append(.stageSelect)
                    } label: {
                        Label("开始", systemImage: "play.fill")
                            .font(.headline)
                            .frame(maxWidth: 260)
                            .padding(.vertical, 14)
                            .background(Capsule().fill(Color.accentColor))
                            .foregroundStyle(.white)
                    }

                    Button {
                        showSettings = true
                    } label: {
                        Label("设置", systemImage: "gearshape")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.85))
                    }
                    .padding(.bottom, 40)
                }
            }
            .navigationDestination(for: Route.self) { route in
                switch route {
                case .stageSelect:
                    StageSelectView { level in
                        path.append(.level(level))
                    }
                case .level(let id):
                    LevelScreen(levelID: id)
                }
            }
        }
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
    }
}
