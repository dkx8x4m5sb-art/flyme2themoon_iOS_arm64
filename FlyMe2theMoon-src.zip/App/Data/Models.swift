//
//  Models.swift
//  与 Resources/data/*.json、Resources/atlas/normalized.json 一一对应的数据结构。
//

import CoreGraphics
import Foundation

// MARK: - 关卡

struct LevelData: Decodable {
    struct Layer: Decodable {
        let name: String
        let type: Int
        let w: Double
        let h: Double
        let objs: [Obj]
    }

    struct Obj: Decodable {
        let x: Double
        let y: Double
        let seq: Int
        let d: Int
        let rot: Double
        let flip: Bool
    }

    let id: Int
    let w: Double
    let h: Double
    let born: [Double]
    let suite: Int
    let layers: [Layer]

    var bornPoint: CGPoint {
        CGPoint(x: CGFloat(born.first ?? w / 2), y: CGFloat(born.count > 1 ? born[1] : h / 2))
    }
}

// MARK: - 图集（已归一化：没有 rotated）

struct AtlasFile: Decodable {
    struct Sheet: Decodable {
        struct Page: Decodable {
            let image: String
            let size: [Int]
        }

        struct Frame: Decodable {
            let x: Int
            let y: Int
            let w: Int
            let h: Int
            let p: Int?
            let ox: Int
            let oy: Int
            let sw: Int
            let sh: Int
            let cx: Int
            let cy: Int

            var rect: CGRect { CGRect(x: x, y: y, width: w, height: h) }
            var size: CGSize { CGSize(width: w, height: h) }
        }

        let pages: [Page]
        let frames: [String: Frame]
    }

    let sheets: [String: Sheet]
}

// MARK: - 对话 / 评分 / 选关

struct DialogLine: Decodable {
    let t: String
    let f: String
    let k: String
}

struct ScoreFile: Decodable {
    let svrs: [String: Double]
}

struct StageSelectFile: Decodable {
    let levels: [String: [Double]]
    let connections: [String: [[Int]]]
}

// MARK: - 物理参数（role.json 原样搬过来）

struct RoleParams: Decodable {
    let maxF: Double
    let maxP: Double
    let mass: Double
    let damping: Double
    let maxXSpeed: Double
    let extraXDamping: Double
    let extraNonFlyXDamping: Double
    let yGravity: Double
    let pushAngleRange: Double
    let pushAngleBound1: Double
    let pushAngleBound2: Double
    let stableFlyRate: Double
    let pushDistance1: Double
    let pushDistance2: Double
}

// MARK: - 存档

struct SaveFile: Codable {
    var passed: [String: Bool] = [:]
    var bestTime: [String: Double] = [:]
    var stars: [String: Int] = [:]
    var flags: [String: Bool] = [:]
}
