//
//  GameData.swift
//  一次性把 Resources 里的 JSON / 图集 / 对话 / 音效索引读进内存。
//

import CoreGraphics
import Foundation
import SpriteKit
import UIKit

final class GameData {
    static let shared = GameData()

    let levels: [String: LevelData]
    let atlas: AtlasFile
    let dialogs: [String: DialogLine]
    let role: RoleParams
    let scores: [String: Double]
    let stageSelect: StageSelectFile
    let dependency: [String: [Int]]
    let sounds: Set<String>
    let faces: Set<String>
    let music: [String]
    /// StaticObject seq → 碰撞多边形（世界坐标）
    let edgesPolygons: [Int: [CGPoint]]

    private var textures: [String: [SKTexture]] = [:]
    private let resourceRoot: URL

    private init() {
        resourceRoot = Bundle.main.resourceURL!.appendingPathComponent("Resources", isDirectory: true)

        func json<T: Decodable>(_ path: String, as: T.Type) -> T {
            let url = resourceRoot.appendingPathComponent(path)
            guard let data = try? Data(contentsOf: url) else {
                fatalError("缺资源：\(path)")
            }
            do {
                return try JSONDecoder().decode(T.self, from: data)
            } catch {
                fatalError("解析 \(path) 失败：\(error)")
            }
        }

        levels = json("data/levels.json", as: [String: LevelData].self)
        atlas = json("atlas/normalized.json", as: AtlasFile.self)
        role = json("data/role.json", as: RoleParams.self)
        stageSelect = json("data/levelselect.json", as: StageSelectFile.self)
        dependency = json("data/dependency.json", as: [String: [Int]].self)
        scores = json("data/score.json", as: ScoreFile.self).svrs

        let rawEdges = json("data/edges.json", as: [String: [[Double]]].self)
        var poly: [Int: [CGPoint]] = [:]
        for (key, pts) in rawEdges {
            guard let id = Int(key) else { continue }
            poly[id] = pts.compactMap { $0.count >= 2 ? CGPoint(x: $0[0], y: $0[1]) : nil }
        }
        edgesPolygons = poly

        let rawDialogs = json("data/dialogs.json", as: [String: [DialogLine]].self)
        var index: [String: DialogLine] = [:]
        for list in rawDialogs.values {
            for line in list where !line.k.isEmpty {
                index[line.k] = line
            }
        }
        dialogs = index

        let audioDir = resourceRoot.appendingPathComponent("audio", isDirectory: true)
        let audioFiles = (try? FileManager.default.contentsOfDirectory(atPath: audioDir.path)) ?? []
        sounds = Set(audioFiles.filter { $0.hasSuffix(".wav") }.map { ($0 as NSString).deletingPathExtension })
        music = ["Hectic", "MoonTrip", "SkyTunnel", "SpiralofAdventure", "SymphonyofRush", "LifeforSpeed"]

        let artDir = resourceRoot.appendingPathComponent("art", isDirectory: true)
        let artFiles = (try? FileManager.default.contentsOfDirectory(atPath: artDir.path)) ?? []
        faces = Set(artFiles.filter { $0.hasPrefix("face") }.map { ($0 as NSString).deletingPathExtension })
    }

    /// Resources 下的文件 URL
    func url(_ relative: String) -> URL { resourceRoot.appendingPathComponent(relative) }

    func image(_ relative: String) -> UIImage? { UIImage(contentsOfFile: url(relative).path) }

    func faceImage(_ name: String) -> UIImage? { image("art/(name).png") }

    // MARK: - 关卡

    var levelIDs: [Int] {
        levels.keys.compactMap(Int.init).sorted()
    }

    func level(_ id: Int) -> LevelData? {
        levels[String(id)]
    }

    // MARK: - 图集

    /// 某组图集的所有分页贴图（懒加载）
    func pages(of sheet: String) -> [SKTexture] {
        if let cached = textures[sheet] { return cached }
        guard let def = atlas.sheets[sheet] else { return [] }
        var out: [SKTexture] = []
        for page in def.pages {
            let url = resourceRoot.appendingPathComponent("atlas/\(page.image)")
            guard let image = UIImage(contentsOfFile: url.path) else { continue }
            out.append(SKTexture(image: image))
        }
        textures[sheet] = out
        return out
    }

    func frame(_ name: String, in sheet: String) -> AtlasFile.Sheet.Frame? {
        atlas.sheets[sheet]?.frames[name]
    }

    /// 名字前缀匹配：先找精确帧，再找 `<name>/...` 的动画序列（按名字排序）
    func animationFrames(_ base: String, in sheet: String) -> [String] {
        guard let def = atlas.sheets[sheet] else { return [] }
        if def.frames[base] != nil { return [base] }
        let key = base.hasSuffix(".png") ? String(base.dropLast(4)) : base
        return def.frames.keys.filter { $0 == key || $0.hasPrefix("\(key)/") }.sorted()
    }

    func texture(_ frameName: String, in sheet: String) -> SKTexture? {
        guard let def = atlas.sheets[sheet],
              let f = def.frames[frameName],
              !def.pages.isEmpty else { return nil }
        let pageList = def.pages
        let all = pages(of: sheet)
        guard !all.isEmpty else { return nil }
        let index = min(max(f.p ?? 0, 0), all.count - 1)
        let page = pageList[min(index, pageList.count - 1)]
        let imageSize = CGSize(width: page.size[0], height: page.size[1])
        let rect = CGRect(
            x: CGFloat(f.x) / imageSize.width,
            y: CGFloat(f.y) / imageSize.height,
            width: CGFloat(f.w) / imageSize.width,
            height: CGFloat(f.h) / imageSize.height
        )
        let tex = SKTexture(rect: rect, in: all[index])
        tex.filteringMode = .linear
        return tex
    }

    // MARK: - 图层 → 图集

    func sheet(for layer: String, suite: Int) -> String? {
        switch layer {
        case "Background", "Farground": return "FargroundsS\(suite)-hd"
        case "Texture", "Foreground": return "TextureS\(suite)-hd"
        case "Item", "DynamicObject": return "DynamicObjectsLite-hd"
        default: return nil
        }
    }

    func frameBase(for layer: String, seq: Int) -> String? {
        switch layer {
        case "Background": return String(format: "Background_%03d.png", seq)
        case "Farground": return String(format: "Farground_%03d.png", seq)
        case "Texture": return String(format: "Texture_%03d.png", seq)
        case "Foreground": return String(format: "Foreground_%03d.png", seq)
        case "Item": return String(format: "Item_%03d", seq)
        case "DynamicObject": return String(format: "DynamicObject_%03d", seq)
        default: return nil
        }
    }

    func characterSheet() -> String { "CharActions-hd" }

    // MARK: - 对话 / 评分

    func dialog(_ key: String) -> DialogLine? { dialogs[key] }

    func starThresholds(_ level: Int) -> Double { scores[String(level)] ?? 0 }

    func unlockedLevels(passed: [String: Bool]) -> Set<Int> {
        var open: Set<Int> = [1]
        for (key, need) in dependency {
            guard let id = Int(key) else { continue }
            let ok = need.allSatisfy { passed[String($0)] == true }
            if ok { open.insert(id) }
        }
        for (key, done) in passed where done { if let id = Int(key) { open.insert(id) } }
        return open
    }
}
