//
//  ProgressStore.swift
//  存档：通关、最佳时间、星级、global.setBool 的剧情标记。全部进 UserDefaults。
//

import Foundation

final class ProgressStore {
    static let shared = ProgressStore()

    private let key = "fm.save.v1"
    private var save: SaveFile

    private init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode(SaveFile.self, from: data) {
            save = decoded
        } else {
            save = SaveFile()
        }
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(save) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    var passed: [String: Bool] { save.passed }

    func isPassed(_ level: Int) -> Bool { save.passed[String(level)] == true }

    func markPassed(_ level: Int, time: Double, stars: Int) {
        let k = String(level)
        save.passed[k] = true
        if let best = save.bestTime[k] {
            save.bestTime[k] = min(best, time)
        } else {
            save.bestTime[k] = time
        }
        save.stars[k] = max(save.stars[k] ?? 0, stars)
        persist()
    }

    func stars(_ level: Int) -> Int { save.stars[String(level)] ?? 0 }
    func bestTime(_ level: Int) -> Double? { save.bestTime[String(level)] }

    func getFlag(_ name: String) -> Bool { save.flags[name] == true }

    func setFlag(_ name: String) {
        save.flags[name] = true
        persist()
    }

    func unlockedLevels() -> Set<Int> {
        GameData.shared.unlockedLevels(passed: save.passed)
    }

    /// 通关时长算星：阈值来自 score.json 的 svrs（秒）
    func starsFor(level: Int, time: Double) -> Int {
        let threshold = GameData.shared.starThresholds(level)
        guard threshold > 0 else { return time > 0 ? 1 : 0 }
        if time <= threshold { return 3 }
        if time <= threshold * 1.6 { return 2 }
        return 1
    }
}
