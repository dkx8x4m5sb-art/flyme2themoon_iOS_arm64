//
//  GameSession.swift
//  SwiftUI ↔ SpriteKit ↔ Lua 的胶水：HUD、对话框、通关结果都在这里汇总。
//

import Foundation
import SpriteKit
import SwiftUI

struct DialogState: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let face: String
    let autoClose: Double
}

final class GameSession: ObservableObject, LevelSceneDelegate {
    let levelID: Int
    let scene: LevelScene

    @Published var dialog: DialogState?
    @Published var time: Double = 0
    @Published var fails: Int = 0
    @Published var result: (passed: Bool, time: Double)?
    @Published var tutorial: Int = 0

    private var lastHUD = Date.distantPast
    private var autoTimer: Timer?

    init(levelID: Int) {
        self.levelID = levelID
        let scene = LevelScene(levelID: levelID)
        self.scene = scene
        scene.levelDelegate = self
    }

    // MARK: - LevelSceneDelegate

    func sceneDidRequestDialog(_ key: String, face: String, minTime: Double) {
        Task { @MainActor in
            self.dialog = DialogState(text: key, face: face, autoClose: minTime)
            self.autoTimer?.invalidate()
            if minTime > 0 {
                self.autoTimer = Timer.scheduledTimer(withTimeInterval: minTime, repeats: false) { _ in
                    Task { @MainActor in self.advanceDialog() }
                }
            }
        }
    }

    func sceneDidUpdateHUD(time: Double, fails: Int) {
        Task { @MainActor in
            // HUD 每帧都来，10Hz 足够
            if Date().timeIntervalSince(self.lastHUD) < 0.1 { return }
            self.lastHUD = Date()
            self.time = time
            self.fails = fails
        }
    }

    func sceneDidFinish(passed: Bool, time: Double) {
        Task { @MainActor in
            self.autoTimer?.invalidate()
            self.dialog = nil
            self.result = (passed, time)
        }
    }

    // MARK: - 交互

    func advanceDialog() {
        guard dialog != nil else { return }
        autoTimer?.invalidate()
        dialog = nil
        scene.luaEngine?.resolveDialog(skipped: true)
    }

    func restartLevel() {
        autoTimer?.invalidate()
        dialog = nil
        result = nil
        scene.prepareRestart()
    }

    func showTutorialDiagram(_ index: Int) {
        tutorial = index
        if index == 0 { return }
        // 原版是图片教程；这里没有素材，用 3 秒文字提示代替
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in
            guard let self, self.tutorial == index else { return }
            self.tutorial = 0
        }
    }
}
