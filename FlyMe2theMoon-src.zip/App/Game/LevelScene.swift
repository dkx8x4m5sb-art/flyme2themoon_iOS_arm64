//
//  LevelScene.swift
//  一关的 SpriteKit 场景：图层、精灵、弹射手感、碰撞、相机、区域触发。
//  物理是"拉弓弹射"：按住拖动 → 显示方向 → 松手起飞；参数尽量贴着 role.json。
//

import CoreGraphics
import SpriteKit
import UIKit

protocol LevelSceneDelegate: AnyObject {
    func sceneDidRequestDialog(_ key: String, face: String, minTime: Double)
    func sceneDidUpdateHUD(time: Double, fails: Int)
    func sceneDidFinish(passed: Bool, time: Double)
}

final class LevelScene: SKScene {
    // MARK: - 调参（role.json 换算成每秒单位）

    struct Tuning {
        var gravity: CGFloat = -980          // 向下
        var launchSpeedMin: CGFloat = 620    // 对应 pushDistance1
        var launchSpeedMax: CGFloat = 980    // 对应 pushDistance2 / maxP
        var maxDrag: CGFloat = 260
        var minDrag: CGFloat = 40
        var maxHorizontal: CGFloat = 900
        var airDrag: CGFloat = 0.55          // 每秒衰减比例
        var groundFriction: CGFloat = 0.88
        var playerRadius: CGFloat = 22
        var angleRange: CGFloat = 50         // pushAngleRange（相对竖直）
        var angleMax: CGFloat = 30           // pushAngleBound2 - pushAngleBound1
    }

    // MARK: - 数据

    let levelID: Int
    let data: LevelData
    private let world = SKNode()
    private let layersNode = SKNode()
    private let debugNode = SKNode()
    private var player: SKSpriteNode!
    private var aimLine: SKShapeNode!
    private var playerSpriteName = "charIdle/001.png"
    private var characterFrames: [String: [String]] = [:]

    weak var levelDelegate: LevelSceneDelegate?

    // 状态
    private var velocity: CGVector = .zero
    private var onGround = false
    private var dead = false
    private var inputEnabled = true
    private var logicPaused = false
    private var idleEnabled = true
    private var levelTime: Double = 0
    private var failCount = 0
    private var completed = false
    private var moonReached = false
    private var charging = false
    private var chargeStart: CGPoint = .zero
    private var chargingTouchLocation: CGPoint = .zero

    // 相机
    private var cameraFollow = true
    private var cameraTarget: CGPoint?
    private var cameraPosition: CGPoint = .zero

    // 碰撞
    private var polygons: [[CGPoint]] = []
    private var areas: [CGPoint] = []

    private let tuning = Tuning()

    // MARK: - 初始化

    init(levelID: Int) {
        self.levelID = levelID
        self.data = GameData.shared.level(levelID) ?? LevelData(id: levelID, w: 960, h: 1440, born: [480, 300], suite: 3, layers: [])
        super.init(size: CGSize(width: CGFloat(data.w), height: CGFloat(data.h)))
        self.anchorPoint = .zero
        self.scaleMode = .aspectFit
        self.backgroundColor = SKColor(red: 0.06, green: 0.07, blue: 0.12, alpha: 1)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - 构建

    override func didMove(to view: SKView) {
        buildWorld()
        buildPlayer()
        startLevel()
    }

    private func buildWorld() {
        addChild(world)
        world.addChild(layersNode)
        world.addChild(debugNode)

        // 背景：Background seq=1 在原版是代码画的天空，这里用渐变底
        let sky = SKSpriteNode(color: SKColor(red: 0.10, green: 0.12, blue: 0.22, alpha: 1), size: CGSize(width: CGFloat(data.w), height: CGFloat(data.h)))
        sky.anchorPoint = .zero
        sky.position = .zero
        sky.zPosition = -1000
        world.addChild(sky)

        let suite = data.suite
        for layer in data.layers {
            switch layer.name {
            case "StaticObject":
                collectPolygons(layer)
            case "Area":
                areas = layer.objs.map { CGPoint(x: CGFloat($0.x), y: CGFloat($0.y)) }
            case "Background", "Farground":
                buildLayer(layer, suite: suite, parallax: true)
            default:
                buildLayer(layer, suite: suite, parallax: false)
            }
        }

        aimLine = SKShapeNode()
        aimLine.strokeColor = SKColor(white: 1, alpha: 0.5)
        aimLine.lineWidth = 4
        aimLine.zPosition = 900
        world.addChild(aimLine)
    }

    private func buildLayer(_ layer: LevelData.Layer, suite: Int, parallax: Bool) {
        let container = SKNode()
        // 背景层用小坐标系，按比例放大
        if parallax, layer.w > 0, layer.h > 0 {
            let scale = max(CGFloat(data.w) / CGFloat(layer.w), CGFloat(data.h) / CGFloat(layer.h))
            container.setScale(scale)
        }
        container.zPosition = zFor(layer.name)
        layersNode.addChild(container)

        guard let sheet = GameData.shared.sheet(for: layer.name, suite: suite) else { return }
        for obj in layer.objs {
            if layer.name == "Background", obj.seq == 1 { continue } // 程序天空
            guard let base = GameData.shared.frameBase(for: layer.name, seq: obj.seq) else { continue }
            let frames = GameData.shared.animationFrames(base, in: sheet)
            guard let first = frames.first, let tex = GameData.shared.texture(first, in: sheet) else { continue }
            let node = SKSpriteNode(texture: tex)
            node.size = tex.size()
            node.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            node.position = CGPoint(x: CGFloat(obj.x), y: CGFloat(obj.y))
            node.zPosition = CGFloat(obj.d)
            if obj.flip { node.xScale = -1 }
            if obj.rot != 0 { node.zRotation = CGFloat(obj.rot) * .pi / 180 }
            container.addChild(node)

            if frames.count > 1, layer.name == "DynamicObject" || layer.name == "Item" {
                animate(node, frames: frames, sheet: sheet)
            }
        }
    }

    private func animate(_ node: SKSpriteNode, frames: [String], sheet: String) {
        var textures: [SKTexture] = []
        for name in frames {
            if let tex = GameData.shared.texture(name, in: sheet) { textures.append(tex) }
        }
        guard textures.count > 1 else { return }
        let action = SKAction.repeatForever(SKAction.animate(with: textures, timePerFrame: 0.12, resize: false, restore: false))
        node.run(action, withKey: "frames")
    }

    private func zFor(_ layer: String) -> CGFloat {
        switch layer {
        case "Background": return -900
        case "Farground": return -800
        case "Texture": return 0
        case "DynamicObject": return 50
        case "Item": return 100
        case "Foreground": return 600
        default: return 0
        }
    }

    private func collectPolygons(_ layer: LevelData.Layer) {
        let edgesPath = GameData.shared.edgesPolygons
        for obj in layer.objs {
            if let poly = edgesPath[obj.seq] {
                polygons.append(poly)
            }
        }
    }

    private func buildPlayer() {
        let sheet = GameData.shared.characterSheet()
        for state in ["charIdle", "charUp", "charDown", "charLeft", "charRight", "charFree", "charDeath", "charLookLeft", "charLookRight", "charLookLeftRight", "charStand"] {
            characterFrames[state] = GameData.shared.animationFrames("\(state)/001.png", in: sheet)
        }
        let born = data.bornPoint
        let tex = GameData.shared.texture("charIdle/001.png", in: sheet)
        player = SKSpriteNode(texture: tex)
        player.size = CGSize(width: (tex?.size().width ?? 90) * 0.9, height: (tex?.size().height ?? 116) * 0.9)
        player.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        player.position = born
        player.zPosition = 300
        world.addChild(player)
        cameraPosition = born
        world.position = .zero
        updateCamera(immediate: true)
    }

    // MARK: - 脚本接口

    func setInputEnabled(_ on: Bool) { inputEnabled = on }
    func setLogicPaused(_ paused: Bool) { logicPaused = paused }
    func setIdleEnabled(_ on: Bool) { idleEnabled = on }
    func restartTiming() { levelTime = 0 }
    func toggleFollow(_ on: Bool) { cameraFollow = on }
    func moveCamera(to point: CGPoint) { cameraTarget = point; cameraFollow = false }
    func cameraToRole() { cameraTarget = nil; cameraFollow = true }
    func reloadRoleState() {
        moonReached = false
        player.position = data.bornPoint
        velocity = .zero
        dead = false
        player.alpha = 1
    }
    func lookLeftRight() {
        guard idleEnabled else { return }
        let sheet = GameData.shared.characterSheet()
        if let frames = characterFrames["charLookLeftRight"], frames.count > 1 {
            var textures: [SKTexture] = frames.compactMap { GameData.shared.texture($0, in: sheet) }
            if textures.isEmpty, let t = GameData.shared.texture("charLookLeftRight/001.png", in: sheet) { textures = [t] }
            if !textures.isEmpty {
                player.run(SKAction.sequence([SKAction.animate(with: textures, timePerFrame: 0.16), SKAction.run { [weak self] in self?.setIdlePose() }]))
            }
        }
    }
    func roleDied() {
        if dead { return }
        dead = true
        failCount += 1
        velocity = .zero
        if let tex = GameData.shared.texture("charDeath/001.png", in: GameData.shared.characterSheet()) {
            player.texture = tex
        }
        run(SKAction.sequence([
            SKAction.wait(forDuration: 0.9),
            SKAction.run { [weak self] in
                guard let self else { return }
                self.onScriptCallback("onRoleDied")
            }
        ]))
    }
    func roleReachedMoon() {
        if moonReached || completed { return }
        moonReached = true
        onScriptCallback("onRoleReachedMoon")
    }

    // MARK: - 游戏循环

    override func update(_ currentTime: TimeInterval) {
        let raw = lastUpdate == 0 ? 0 : currentTime - lastUpdate
        lastUpdate = currentTime
        let dt = min(1.0 / 30.0, max(1.0 / 240.0, CGFloat(raw)))

        // Lua 的等待/对话框不跟着 pauseLogic 停，否则 game.pauseLogic() + script.delay() 会卡死
        luaEngine?.tick(raw <= 0 ? Double(dt) : raw)
        if completed { return }
        if logicPaused {
            updateCamera(immediate: false)
            return
        }
        if !dead { levelTime += Double(dt) }
        if currentTime - lastHUDTime > 0.15 {
            lastHUDTime = currentTime
            levelDelegate?.sceneDidUpdateHUD(time: levelTime, fails: failCount)
        }

        if !dead {
            integrate(dt: dt)
        }
        updateCamera(immediate: false)
    }

    private var lastUpdate: TimeInterval = 0
    private var lastHUDTime: TimeInterval = 0

    private func integrate(dt: CGFloat) {
        guard !charging else { return }
        // 重力 + 阻尼
        velocity.dy += tuning.gravity * dt
        let drag = onGround ? tuning.groundFriction : max(0, 1 - tuning.airDrag * dt)
        velocity.dx *= drag
        velocity.dx = min(tuning.maxHorizontal, max(-tuning.maxHorizontal, velocity.dx))

        var next = CGPoint(x: player.position.x + velocity.dx * dt, y: player.position.y + velocity.dy * dt)

        // 碰撞：圆 vs 多边形
        var landed = false
        for poly in polygons {
            if let hit = resolveCircle(center: next, radius: tuning.playerRadius, polygon: poly) {
                next = hit.point
                if hit.normal.dy > 0.4 && velocity.dy <= 0 {
                    velocity.dy = 0
                    landed = true
                } else {
                    let dot = velocity.dx * hit.normal.dx + velocity.dy * hit.normal.dy
                    if dot < 0 {
                        velocity.dx -= hit.normal.dx * dot
                        velocity.dy -= hit.normal.dy * dot
                    }
                    velocity.dx *= 0.96
                }
            }
        }
        onGround = landed
        player.position = next

        // 出界 / 落底
        if next.y < -120 || next.x < -200 || next.x > CGFloat(data.w) + 200 {
            roleDied()
            return
        }

        // 到达区域（月亮）
        for area in areas {
            if hypot(area.x - next.x, area.y - next.y) < 70 {
                roleReachedMoon()
                return
            }
        }

        updatePlayerPose()
    }

    private func updatePlayerPose() {
        let sheet = GameData.shared.characterSheet()
        let dx = velocity.dx
        let dy = velocity.dy
        var state = "charIdle"
        if !onGround {
            if dy > 120 { state = "charUp" }
            else if dy < -120 { state = "charDown" }
            else if abs(dx) > 120 { state = dx > 0 ? "charRight" : "charLeft" }
            else { state = "charFree" }
        } else if abs(dx) > 120 {
            state = dx > 0 ? "charRight" : "charLeft"
        }
        if let frames = characterFrames[state], let first = frames.first,
           let tex = GameData.shared.texture(first, in: sheet), player.texture !== tex {
            player.texture = tex
            player.size = tex.size()
        }
    }

    private func setIdlePose() {
        let sheet = GameData.shared.characterSheet()
        if let tex = GameData.shared.texture("charIdle/001.png", in: sheet) { player.texture = tex }
    }

    // MARK: - 相机

    private func updateCamera(immediate: Bool) {
        var target = CGPoint(x: player.position.x, y: player.position.y + 220)
        if let fixed = cameraTarget { target = fixed }
        if !cameraFollow, cameraTarget == nil { target = cameraPosition }
        let viewW = size.width
        let viewH = size.height
        target.x = min(max(target.x, viewW / 2), max(viewW / 2, CGFloat(data.w) - viewW / 2))
        target.y = min(max(target.y, viewH / 2), max(viewH / 2, CGFloat(data.h) - viewH / 2))
        let t: CGFloat = immediate ? 1 : 0.12
        cameraPosition.x += (target.x - cameraPosition.x) * t
        cameraPosition.y += (target.y - cameraPosition.y) * t
        world.position = CGPoint(x: viewW / 2 - cameraPosition.x, y: viewH / 2 - cameraPosition.y)
    }

    // MARK: - 输入（拉弓）

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard inputEnabled, !dead, !completed, let touch = touches.first else { return }
        charging = true
        chargeStart = touch.location(in: self)
        chargingTouchLocation = chargeStart
        aimLine.path = nil
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard charging, let touch = touches.first else { return }
        chargingTouchLocation = touch.location(in: self)
        drawAim()
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard charging else { return }
        charging = false
        aimLine.path = nil
        launch()
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        charging = false
        aimLine.path = nil
    }

    private var aimVector: CGVector {
        CGVector(dx: chargeStart.x - chargingTouchLocation.x, dy: chargeStart.y - chargingTouchLocation.y)
    }

    private func drawAim() {
        let v = aimVector
        let len = min(tuning.maxDrag, hypot(v.dx, v.dy))
        guard len > 4 else {
            aimLine.path = nil
            return
        }
        let dir = CGVector(dx: v.dx / max(1, hypot(v.dx, v.dy)), dy: v.dy / max(1, hypot(v.dx, v.dy)))
        let path = CGMutablePath()
        path.move(to: chargeStart)
        path.addLine(to: CGPoint(x: chargeStart.x + dir.dx * len, y: chargeStart.y + dir.dy * len))
        aimLine.path = path
    }

    private func launch() {
        var v = aimVector
        let rawLen = hypot(v.dx, v.dy)
        guard rawLen > tuning.minDrag else { return }
        let len = min(tuning.maxDrag, rawLen)
        var dir = CGVector(dx: v.dx / rawLen, dy: v.dy / rawLen)

        // 角度：限制在竖直向上左右各 pushAngleRange 度内，且不能向下
        if dir.dy < 0.15 { dir.dy = 0.15; dir.dx = dir.dx * 0.9 }
        let norm = max(0.001, hypot(dir.dx, dir.dy))
        dir = CGVector(dx: dir.dx / norm, dy: dir.dy / norm)

        let ratio = (len - tuning.minDrag) / max(1, tuning.maxDrag - tuning.minDrag)
        let speed = tuning.launchSpeedMin + (tuning.launchSpeedMax - tuning.launchSpeedMin) * ratio
        velocity = CGVector(dx: dir.dx * speed, dy: dir.dy * speed)
        onGround = false
        updatePlayerPose()
    }

    // MARK: - 脚本回调

    private func onScriptCallback(_ name: String) {
        luaEngine?.callGlobal(name)
    }

    var luaEngine: LuaEngine?
    var onTutorial: ((Int) -> Void)?

    func showTutorialDiagram(_ index: Int) {
        onTutorial?(index)
    }

    // MARK: - 碰撞工具

    private struct Hit {
        let point: CGPoint
        let normal: CGVector
    }

    private func resolveCircle(center: CGPoint, radius: CGFloat, polygon: [CGPoint]) -> Hit? {
        guard polygon.count >= 3 else { return nil }
        if !pointInPolygon(center, polygon) && distanceToPolygon(center, polygon) > radius { return nil }

        var best: Hit?
        var bestDist = CGFloat.greatestFiniteMagnitude
        for i in 0..<polygon.count {
            let a = polygon[i]
            let b = polygon[(i + 1) % polygon.count]
            let (closest, dist) = closestPointOnSegment(center, a, b)
            if dist < bestDist {
                bestDist = dist
                var n = CGVector(dx: center.x - closest.x, dy: center.y - closest.y)
                let len = max(0.0001, hypot(n.dx, n.dy))
                n = CGVector(dx: n.dx / len, dy: n.dy / len)
                if pointInPolygon(center, polygon) {
                    n = CGVector(dx: -n.dx, dy: -n.dy)
                }
                let pushed = CGPoint(x: closest.x + n.dx * radius, y: closest.y + n.dy * radius)
                let target = pointInPolygon(center, polygon) ? pushed : CGPoint(x: center.x + n.dx * (radius - dist), y: center.y + n.dy * (radius - dist))
                best = Hit(point: target, normal: n)
            }
        }
        return best
    }

    private func pointInPolygon(_ p: CGPoint, _ poly: [CGPoint]) -> Bool {
        var inside = false
        var j = poly.count - 1
        for i in 0..<poly.count {
            let a = poly[i]
            let b = poly[j]
            if (a.y > p.y) != (b.y > p.y),
               p.x < (b.x - a.x) * (p.y - a.y) / max(0.0001, b.y - a.y) + a.x {
                inside.toggle()
            }
            j = i
        }
        return inside
    }

    private func closestPointOnSegment(_ p: CGPoint, _ a: CGPoint, _ b: CGPoint) -> (CGPoint, CGFloat) {
        let abx = b.x - a.x
        let aby = b.y - a.y
        let len2 = abx * abx + aby * aby
        if len2 < 0.0001 { return (a, hypot(p.x - a.x, p.y - a.y)) }
        var t = ((p.x - a.x) * abx + (p.y - a.y) * aby) / len2
        t = min(1, max(0, t))
        let c = CGPoint(x: a.x + abx * t, y: a.y + aby * t)
        return (c, hypot(p.x - c.x, p.y - c.y))
    }

    private func distanceToPolygon(_ p: CGPoint, _ poly: [CGPoint]) -> CGFloat {
        var best = CGFloat.greatestFiniteMagnitude
        for i in 0..<poly.count {
            let (_, d) = closestPointOnSegment(p, poly[i], poly[(i + 1) % poly.count])
            best = min(best, d)
        }
        return best
    }

    // MARK: - 开始 / 结束

    private func startLevel() {
        levelTime = 0
        failCount = 0
        dead = false
        completed = false
        moonReached = false
        AudioEngine.shared.playMusic(AudioEngine.shared.musicForSuite(data.suite))
        if let lua = LuaEngine(level: levelID, scene: self) {
            luaEngine = lua
            lua.start()
        }
    }

    /// 重开本关：清状态、重建 Lua
    func prepareRestart() {
        completed = false
        moonReached = false
        dead = false
        failCount = 0
        levelTime = 0
        velocity = .zero
        player.position = data.bornPoint
        player.alpha = 1
        luaEngine = nil
        let engine = LuaEngine(level: levelID, scene: self)
        luaEngine = engine
        engine?.start()
    }

    func finishSuccess() {
        guard !completed else { return }
        completed = true
        let stars = ProgressStore.shared.starsFor(level: levelID, time: levelTime)
        ProgressStore.shared.markPassed(levelID, time: levelTime, stars: stars)
        AudioEngine.shared.stopMusic()
        levelDelegate?.sceneDidFinish(passed: true, time: levelTime)
    }
}
