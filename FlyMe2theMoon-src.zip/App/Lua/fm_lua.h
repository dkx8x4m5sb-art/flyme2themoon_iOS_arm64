//
//  fm_lua.h
//  只做一件事：建一个只开了安全库的 Lua 5.1 状态。
//  iOS 上不编译 io / os / loadlib（它们要文件系统与 dlopen），关卡脚本也用不到。
//

#ifndef FM_LUA_H
#define FM_LUA_H

#include "lua.h"

/// 新建 Lua 状态并注册 base / table / string / math / coroutine / debug。
/// 失败返回 NULL。
lua_State *fm_lua_new(void);

#endif
