//
//  LuaEngine.swift
//  每关跑两段 Lua：先 prelude（把 dialog/game/camera… 做成 Lua 函数），再跑关卡脚本。
//  阻塞行为（对话框、等待）都用 coroutine.yield 交给 Swift 驱动。
//  注意：Lua 5.1 的协程死了就不能再 resume，所以关卡本体和每次回调各开一个新线程。
//

import CoreGraphics
import Foundation

private final class LuaRegistry {
    static var current: LuaEngine?
}

private let LUA_REGISTRYINDEX: Int32 = -10000
private let LUA_GLOBALSINDEX: Int32 = -10002
private let LUA_YIELD: Int32 = 1
private let LUA_TFUNCTION: Int32 = 6

final class LuaEngine {
    private var L: OpaquePointer?
    private weak var scene: LevelScene?
    private let levelID: Int

    private var active: OpaquePointer?
    private var activeRef: Int32 = -1

    private var waitingDelay = false
    private var delayRemaining = 0.0
    private var waitingDialog = false
    private var skipEnabled = false
    private var finished = false
    private var replayScheduled = false

    init?(level: Int, scene: LevelScene) {
        self.levelID = level
        self.scene = scene
        guard let L = fm_lua_new() else { return nil }
        self.L = L
        registerNatives(L)
        LuaRegistry.current = self
        // 表情常量：faceRenzhen = "faceRenzhen"
        for face in GameData.shared.faces {
            lua_pushstring(L, face)
            lua_setglobal(L, face)
        }
    }

    deinit {
        if let L { lua_close(L) }
        if LuaRegistry.current === self { LuaRegistry.current = nil }
    }

    // MARK: - 启动

    func start() {
        guard let src = loadSource() else { return }
        let code = LuaEngine.prelude + "\n" + src
        let name = "@Level_\(String(format: "%03d", levelID)).lua"
        run(code: code, name: name)
    }

    private func loadSource() -> String? {
        let url = Bundle.main.resourceURL!
            .appendingPathComponent("Resources/data/lua/Level_\(String(format: "%03d", levelID)).lua")
        return try? String(contentsOf: url, encoding: .utf8)
    }

    private func run(code: String, name: String) {
        guard let L, let thread = newThread() else { return }
        var status: Int32 = 0
        let loadStatus = code.withCString { cstr in
            luaL_loadbuffer(thread, cstr, Int(strlen(cstr)), name)
        }
        if loadStatus != 0 {
            logError(thread, stage: "load")
            releaseThread()
            return
        }
        status = lua_resume(thread, 0)
        handle(status: status, thread: thread)
    }

    /// 新建一个协程并把它挂在 registry 上（防止 GC），设为 active
    private func newThread() -> OpaquePointer? {
        guard let L, let thread = lua_newthread(L) else { return nil }
        if activeRef >= 0 {
            luaL_unref(L, LUA_REGISTRYINDEX, activeRef)
        }
        activeRef = luaL_ref(L, LUA_REGISTRYINDEX)
        active = thread
        return thread
    }

    private func releaseThread() {
        guard let L, activeRef >= 0 else { return }
        luaL_unref(L, LUA_REGISTRYINDEX, activeRef)
        activeRef = -1
        active = nil
    }

    // MARK: - 每帧驱动

    func tick(_ dt: Double) {
        if finished { return }
        guard waitingDelay else { return }
        delayRemaining -= dt
        if delayRemaining <= 0 {
            waitingDelay = false
            resume(with: [])
        }
    }

    // MARK: - 回调

    func callGlobal(_ name: String) {
        guard let thread = newThread() else { return }
        lua_getfield(thread, LUA_GLOBALSINDEX, name)
        if lua_type(thread, -1) != LUA_TFUNCTION {
            lua_settop(thread, 0)
            releaseThread()
            return
        }
        let status = lua_resume(thread, 0)
        handle(status: status, thread: thread)
    }

    // MARK: - 结果处理

    private func handle(status: Int32, thread: OpaquePointer) {
        if status == LUA_YIELD {
            handleYield(thread: thread)
            return
        }
        if status != 0 {
            logError(thread, stage: "resume")
        }
        lua_settop(thread, 0)
        releaseThread()
    }

    private func handleYield(thread: OpaquePointer) {
        var kind = ""
        var key = ""
        var face = ""
        var minTime = 0.0
        var delay = 0.0
        var autoClose = false

        if lua_gettop(thread) >= 1, lua_istable(thread, -1) != 0 {
            func str(_ field: String) -> String {
                lua_getfield(thread, -1, field)
                let value = lua_tostring(thread, -1).map { String(cString: $0) } ?? ""
                pop(thread, 1)
                return value
            }
            func num(_ field: String) -> Double {
                lua_getfield(thread, -1, field)
                let value = lua_tonumber(thread, -1)
                pop(thread, 1)
                return value
            }
            func flag(_ field: String) -> Bool {
                lua_getfield(thread, -1, field)
                let value = lua_toboolean(thread, -1) != 0
                pop(thread, 1)
                return value
            }
            kind = str("kind")
            key = str("key")
            face = str("face")
            minTime = num("min")
            delay = num("s")
            autoClose = flag("auto")
        }
        lua_settop(thread, 0)

        switch kind {
        case "delay":
            waitingDelay = true
            delayRemaining = max(0.05, delay)
        case "dialog":
            waitingDialog = true
            let line = GameData.shared.dialog(key)
            let text = line?.t ?? key
            let faceName = (line?.f.isEmpty == false ? line?.f : nil) ?? face
            scene?.levelDelegate?.sceneDidRequestDialog(text, face: faceName, minTime: autoClose ? max(0.8, minTime) : 0)
        default:
            resume(with: [])
        }
    }

    private func resume(with ints: [Int32]) {
        guard let thread = active else { return }
        for v in ints { lua_pushinteger(thread, Int(v)) }
        let status = lua_resume(thread, Int32(ints.count))
        handle(status: status, thread: thread)
    }

    /// 玩家点了对话框；1 = 继续，0 = 不可跳过
    func resolveDialog(skipped: Bool) {
        guard waitingDialog else { return }
        waitingDialog = false
        resume(with: [skipped ? 1 : 0])
    }

    // MARK: - 场景事件

    func roleDied() {
        callGlobal("onRoleDied")
    }

    func roleReachedMoon() {
        callGlobal("onRoleReachedMoon")
    }

    // MARK: - 原生函数

    private func logError(_ thread: OpaquePointer, stage: String) {
        if let c = lua_tostring(thread, -1) {
            print("[fm] lua \(stage) failed level \(levelID): \(String(cString: c))")
        }
    }

    private func registerNatives(_ L: OpaquePointer) {
        lua_newtable(L)
        reg(L, "sound_play") { st in
            guard let s = lua_tostring(st, 1) else { return 0 }
            AudioEngine.shared.play(sound: String(cString: s))
            return 0
        }
        reg(L, "cam_goto") { st in
            let x = luaL_checknumber(st, 1)
            let y = luaL_checknumber(st, 2)
            LuaRegistry.current?.scene?.moveCamera(to: CGPoint(x: CGFloat(x), y: CGFloat(y)))
            return 0
        }
        reg(L, "cam_role") { _ in
            LuaRegistry.current?.scene?.cameraToRole()
            return 0
        }
        reg(L, "cam_follow") { st in
            LuaRegistry.current?.scene?.toggleFollow(boolArg(st))
            return 0
        }
        reg(L, "set_input") { st in
            LuaRegistry.current?.scene?.setInputEnabled(boolArg(st))
            return 0
        }
        reg(L, "pause") { _ in
            LuaRegistry.current?.scene?.setLogicPaused(true)
            return 0
        }
        reg(L, "resume") { _ in
            LuaRegistry.current?.scene?.setLogicPaused(false)
            return 0
        }
        reg(L, "restart_timing") { _ in
            LuaRegistry.current?.scene?.restartTiming()
            return 0
        }
        reg(L, "is_restart") { st in
            lua_pushboolean(st, 0)
            return 1
        }
        reg(L, "success") { _ in
            LuaRegistry.current?.finished = true
            LuaRegistry.current?.scene?.finishSuccess()
            return 0
        }
        reg(L, "tutorial") { st in
            let n = Int(luaL_checknumber(st, 1))
            LuaRegistry.current?.scene?.showTutorialDiagram(n)
            return 0
        }
        reg(L, "set_idle") { st in
            LuaRegistry.current?.scene?.setIdleEnabled(boolArg(st))
            return 0
        }
        reg(L, "load_state") { _ in
            LuaRegistry.current?.scene?.reloadRoleState()
            return 0
        }
        reg(L, "look_lr") { _ in
            LuaRegistry.current?.scene?.lookLeftRight()
            return 0
        }
        reg(L, "global_get") { st in
            guard let s = lua_tostring(st, 1) else { return 0 }
            lua_pushboolean(st, ProgressStore.shared.getFlag(String(cString: s)) ? 1 : 0)
            return 1
        }
        reg(L, "global_set") { st in
            guard let s = lua_tostring(st, 1) else { return 0 }
            ProgressStore.shared.setFlag(String(cString: s))
            return 0
        }
        reg(L, "is_passed") { st in
            let n = Int(luaL_checknumber(st, 1))
            lua_pushboolean(st, ProgressStore.shared.isPassed(n) ? 1 : 0)
            return 1
        }
        reg(L, "replay_mode") { _ in 0 }
        reg(L, "play_mode") { _ in 0 }
        reg(L, "load_rep") { st in
            let name = lua_tostring(st, 1).map { String(cString: $0) } ?? ""
            LuaRegistry.current?.scheduleReplay(name)
            return 0
        }
        reg(L, "replay_skip") { _ in 0 }
        reg(L, "replay_pause") { _ in 0 }
        reg(L, "set_skip") { st in
            LuaRegistry.current?.skipEnabled = boolArg(st)
            return 0
        }
        lua_setglobal(L, "fm")
    }

    private func reg(_ L: OpaquePointer, _ name: String, _ fn: @escaping @convention(c) (OpaquePointer?) -> Int32) {
        lua_pushcfunction(L, fn)
        lua_setfield(L, -2, name)
    }

    /// 原版会回放一段录制输入；简化：过两秒当演示结束，让脚本走"演示完成"分支
    private func scheduleReplay(_ name: String) {
        guard !replayScheduled else { return }
        replayScheduled = true
        let scene = self.scene
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            scene?.roleReachedMoon()
        }
    }

    // MARK: - prelude

    private static let prelude = """
    local fm = fm
    dialog = {}
    function dialog.show(k, f, m) return coroutine.yield({kind='dialog', key=k, face=f or '', min=m or 0}) end
    function dialog.showMinTime(k, f, m) return coroutine.yield({kind='dialog', key=k, face=f or '', min=m or 0}) end
    function dialog.showFixedTime(k, f, m) return coroutine.yield({kind='dialog', key=k, face=f or '', min=m or 0, auto=true}) end
    function dialog.setSkipEnabled(v) fm.set_skip(v and true or false) end
    script = {}
    function script.delay(s) coroutine.yield({kind='delay', s=s}) end
    sound = {}
    function sound.play(id) fm.sound_play(id) end
    camera = {}
    function camera.gotoPosition(x, y) fm.cam_goto(x, y) end
    function camera.gotoRole() fm.cam_role() end
    function camera.setFollowRoleMode(v) fm.cam_follow(v and true or false) end
    game = {}
    function game.setUserInputEnabled(v) fm.set_input(v and true or false) end
    function game.pauseLogic() fm.pause() end
    function game.resumeLogic() fm.resume() end
    function game.restartTiming() fm.restart_timing() end
    function game.isRestart() return fm.is_restart() end
    function game.success() fm.success() end
    function game.showTutorialDiagram(n) fm.tutorial(n) end
    function game.setReplayMode() fm.replay_mode() end
    function game.setPlayMode() fm.play_mode() end
    function game.loadTutorialRep(n) fm.load_rep(n) end
    role = {}
    function role.setIdleActionEnabled(v) fm.set_idle(v and true or false) end
    function role.loadState() fm.load_state() end
    function role.lookLeftRight() fm.look_lr() end
    global = {}
    function global.getBool(k) return fm.global_get(k) end
    function global.setBool(k) fm.global_set(k) end
    function global.isLevelPassed(n) return fm.is_passed(n) end
    replay = {}
    function replay.skipNonControlFrames() fm.replay_skip() end
    function replay.pause() fm.replay_pause() end
    """
}

private func pop(_ L: OpaquePointer?, _ n: Int32) {
    lua_settop(L, -(n) - 1)
}

private func boolArg(_ L: OpaquePointer?) -> Bool {
    lua_toboolean(L, 1) != 0
}
