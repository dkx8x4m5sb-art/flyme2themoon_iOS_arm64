//
//  fm_lua.c
//  建状态 + 只开需要的库。关卡脚本只用语言本身和 coroutine。
//

#include "fm_lua.h"
#include "lauxlib.h"
#include "lualib.h"

// liolib.c / loslib.c / loadlib.c 没有编进来，但 luaL_openlibs 会引用这些符号，补空实现。
int luaopen_io(lua_State *L) { (void)L; return 0; }
int luaopen_os(lua_State *L) { (void)L; return 0; }
int luaopen_loadlib(lua_State *L) { (void)L; return 0; }
int luaopen_package(lua_State *L) { (void)L; return 0; }

static const luaL_Reg fm_libs[] = {
    {"", luaopen_base},
    {LUA_TABLIBNAME, luaopen_table},
    {LUA_STRLIBNAME, luaopen_string},
    {LUA_MATHLIBNAME, luaopen_math},
    {LUA_COLIBNAME, luaopen_coroutine},
    {LUA_DBLIBNAME, luaopen_debug},
    {NULL, NULL},
};

lua_State *fm_lua_new(void) {
    lua_State *L = luaL_newstate();
    if (L == NULL) {
        return NULL;
    }
    for (const luaL_Reg *lib = fm_libs; lib->func != NULL; lib++) {
        lua_pushcfunction(L, lib->func);
        lua_pushstring(L, lib->name);
        lua_call(L, 1, 0);
    }
    return L;
}
