//
//  FlyMe2theMoonApp.swift
//  入口。
//

import SwiftUI

@main
struct FlyMe2theMoonApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
                .preferredColorScheme(.dark)
                .statusBarHidden(true)
        }
    }
}
