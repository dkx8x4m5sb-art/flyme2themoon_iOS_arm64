// pack-assets.mjs — 把 Resources 打成一个「够用又不太大」的 zip，方便从手机仓库上传。
// 地形图集（TextureS*/FargroundsS*）降到一半分辨率，角色/道具/音频/数据保持原样。
// 输出：assets-lite.zip（内含 Resources/... 与调整过坐标的 atlas/normalized.json）
import { readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { deflateRawSync } from 'node:zlib'
import { decodePng, encodePng } from './png.mjs'

const RES = 'Resources'
const OUT = process.argv[2] || 'assets-lite.zip'
const HALF = /^(TextureS\d|FargroundsS\d)-hd(-p\d)?\.png$/

function walk(dir, base = '') {
  const out = []
  for (const name of readdirSync(dir)) {
    const full = join(dir, name)
    const rel = base ? `${base}/${name}` : name
    if (statSync(full).isDirectory()) out.push(...walk(full, rel))
    else out.push(rel)
  }
  return out
}

function downscale(img, factor = 2) {
  const w = Math.floor(img.width / factor)
  const h = Math.floor(img.height / factor)
  const out = Buffer.alloc(w * h * 4)
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      let r = 0
      let g = 0
      let b = 0
      let a = 0
      for (let dy = 0; dy < factor; dy += 1) {
        for (let dx = 0; dx < factor; dx += 1) {
          const so = ((y * factor + dy) * img.width + (x * factor + dx)) * 4
          r += img.data[so]
          g += img.data[so + 1]
          b += img.data[so + 2]
          a += img.data[so + 3]
        }
      }
      const n = factor * factor
      const to = (y * w + x) * 4
      out[to] = r / n
      out[to + 1] = g / n
      out[to + 2] = b / n
      out[to + 3] = a / n
    }
  }
  return { width: w, height: h, data: out }
}

// BGM（.caf）体积大，先不进这个包；音乐以后单独补
const files = walk(RES).filter((f) => !f.startsWith('audio/bgm/'))
const entries = []
let rawTotal = 0
let packedTotal = 0

// 先处理图集与 normalized.json
let atlas = JSON.parse(readFileSync(join(RES, 'atlas/normalized.json'), 'utf8'))
const halvedSheets = new Set()

for (const rel of files) {
  const name = rel.split('/').pop()
  const full = join(RES, rel)
  let data = readFileSync(full)
  if (rel.startsWith('atlas/') && HALF.test(name)) {
    const img = decodePng(data)
    const small = downscale(img, 2)
    data = encodePng(small.width, small.height, small.data)
    const sheet = name.replace(/-p\d+\.png$/, '').replace(/\.png$/, '')
    halvedSheets.add(sheet)
    if (data.length > 0) packedTotal += 0
  }
  entries.push({ path: `Resources/${rel}`, data })
  rawTotal += data.length
}

for (const [sheet, def] of Object.entries(atlas.sheets)) {
  if (!halvedSheets.has(sheet)) continue
  def.pages = def.pages.map((p) => ({ image: p.image, size: [Math.floor(p.size[0] / 2), Math.floor(p.size[1] / 2)] }))
  for (const f of Object.values(def.frames)) {
    f.x = Math.floor(f.x / 2)
    f.y = Math.floor(f.y / 2)
    f.w = Math.max(1, Math.floor(f.w / 2))
    f.h = Math.max(1, Math.floor(f.h / 2))
  }
}
entries.push({ path: 'Resources/atlas/normalized.json', data: Buffer.from(JSON.stringify(atlas)) })

// ── 写 zip ──────────────────────────────────────────────────────────
let crcTable = null
function crc32(buf) {
  if (!crcTable) {
    crcTable = new Int32Array(256)
    for (let n = 0; n < 256; n += 1) {
      let c = n
      for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
      crcTable[n] = c
    }
  }
  let c = -1
  for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8)
  return (c ^ -1) >>> 0
}

const locals = []
const centrals = []
let offset = 0
for (const e of entries) {
  const deflated = deflateRawSync(e.data, { level: 9 })
  const crc = crc32(e.data)
  const name = Buffer.from(e.path, 'utf8')
  const local = Buffer.alloc(30 + name.length)
  local.writeUInt32LE(0x04034b50, 0)
  local.writeUInt16LE(20, 4)
  local.writeUInt16LE(0x0800, 6)
  local.writeUInt16LE(8, 8)
  local.writeUInt32LE(crc, 14)
  local.writeUInt32LE(deflated.length, 18)
  local.writeUInt32LE(e.data.length, 22)
  local.writeUInt16LE(name.length, 26)
  name.copy(local, 30)
  locals.push(local, deflated)

  const central = Buffer.alloc(46 + name.length)
  central.writeUInt32LE(0x02014b50, 0)
  central.writeUInt16LE(20, 4)
  central.writeUInt16LE(20, 6)
  central.writeUInt16LE(0x0800, 8)
  central.writeUInt16LE(8, 10)
  central.writeUInt32LE(crc, 16)
  central.writeUInt32LE(deflated.length, 20)
  central.writeUInt32LE(e.data.length, 24)
  central.writeUInt16LE(name.length, 28)
  central.writeUInt32LE(offset, 42)
  name.copy(central, 46)
  centrals.push(central)
  offset += local.length + deflated.length
}

const centralSize = centrals.reduce((n, c) => n + c.length, 0)
const eocd = Buffer.alloc(22)
eocd.writeUInt32LE(0x06054b50, 0)
eocd.writeUInt16LE(entries.length, 8)
eocd.writeUInt16LE(entries.length, 10)
eocd.writeUInt32LE(centralSize, 12)
eocd.writeUInt32LE(offset, 16)

writeFileSync(OUT, Buffer.concat([...locals, ...centrals, eocd]))
console.log(`写出 ${OUT}：${entries.length} 个文件，${(statSync(OUT).size / 1048576).toFixed(1)} MB`)
console.log('降分辨率的图集:', [...halvedSheets].join(', '))
